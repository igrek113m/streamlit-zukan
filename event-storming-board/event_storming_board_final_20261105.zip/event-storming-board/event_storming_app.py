from __future__ import annotations

import copy
import json
from typing import Any

import streamlit as st


st.set_page_config(
    page_title="Event Storming Board",
    page_icon="⚡",
    layout="wide",
)

EMPTY_BOARD: dict[str, Any] = {
    "title": "Event Storming Session",
    "notes": [],
}

HTML = r"""
<div class="es-app edit-mode" tabindex="-1">
  <div class="workspace-shell">
    <header class="control-panel">
      <div class="toolbar-main">
        <div class="board-header">
          <div class="board-brand">
            <span class="board-brand-mark">ES</span>
            <strong title="Event Storming Board">ES Board</strong>
          </div>
        </div>

        <section class="panel-section creator-section" aria-label="要素パレット">
          <div class="object-palette" role="toolbar" aria-label="ドラッグして要素を配置">
            <button type="button" class="palette-item" data-create-kind="domain_event" title="Domain Event：ボードにドラッグして作成" aria-label="Domain Event を作成"><span class="palette-symbol palette-event">▧</span><span>Event</span></button>
            <button type="button" class="palette-item" data-create-kind="command" title="Command：ボードにドラッグして作成" aria-label="Command を作成"><span class="palette-symbol palette-command">▧</span><span>Command</span></button>
            <button type="button" class="palette-item" data-create-kind="read_model" title="Read Model：ボードにドラッグして作成" aria-label="Read Model を作成"><span class="palette-symbol palette-read">▧</span><span>Read</span></button>
            <button type="button" class="palette-item" data-create-kind="aggregate" title="Aggregate：ボードにドラッグして作成" aria-label="Aggregate を作成"><span class="palette-symbol">🏛️</span><span>Aggregate</span></button>
            <button type="button" class="palette-item" data-create-kind="policy" title="Policy：ボードにドラッグして作成" aria-label="Policy を作成"><span class="palette-symbol">⚙️</span><span>Policy</span></button>
            <button type="button" class="palette-item" data-create-kind="actor" title="Actor：ボードにドラッグして作成" aria-label="Actor を作成"><span class="palette-symbol">👤</span><span>Actor</span></button>
            <button type="button" class="palette-item" data-create-kind="hotspot" title="Hot Spot：ボードにドラッグして作成" aria-label="Hot Spot を作成"><span class="palette-symbol">🔥</span><span>Hot Spot</span></button>
            <button type="button" class="palette-item" data-create-kind="external_system" title="External System：ボードにドラッグして作成" aria-label="External System を作成"><span class="palette-symbol">📡</span><span>External</span></button>
          </div>
          <details class="advanced-create-menu">
            <summary title="種類、タイトル、内容を入力して追加">詳細入力</summary>
            <div class="creator-controls">
              <select class="new-note-kind" aria-label="要素の種類">
                <optgroup label="業務要素 / 付箋">
                  <option value="domain_event">Domain Event</option>
                  <option value="command">Command</option>
                  <option value="read_model">Read Model</option>
                </optgroup>
                <optgroup label="意味を持つノード">
                  <option value="aggregate">🏛️ Aggregate</option>
                  <option value="policy">⚙️ Policy</option>
                  <option value="actor">👤 Actor</option>
                  <option value="hotspot">🔥 Hot Spot</option>
                  <option value="external_system">📡 External System</option>
                </optgroup>
              </select>
              <input class="new-note-title" type="text" placeholder="タイトル" />
              <textarea class="new-note-text" rows="2" placeholder="内容・メモ（任意）"></textarea>
              <button class="primary-btn" data-action="add-note">＋追加</button>
            </div>
          </details>
        </section>

        <section class="panel-section compact-panel z-order-panel">
          <div class="compact-panel-head">
            <span class="panel-heading">Z順</span>
            <span class="selected-note-summary" title="選択中の要素">未選択</span>
          </div>
          <div class="z-order-actions">
            <button data-action="step-front" title="1段前面へ" disabled>↑前</button>
            <button data-action="step-back" title="1段背面へ" disabled>↓後</button>
            <button data-action="bring-front" title="最前面へ" disabled>⇈最前</button>
            <button data-action="send-back" title="最背面へ" disabled>⇊最背</button>
          </div>
        </section>

        <section class="panel-section compact-panel utilities">
          <div class="compact-panel-head">
            <span class="panel-heading">ボード</span>
            <span class="stats"></span>
          </div>
          <div class="utility-actions">
            <button data-action="undo" title="Undo">↶</button>
            <button data-action="redo" title="Redo">↷</button>
            <button data-action="export-json" title="JSON保存">保存</button>
            <button data-action="import-json" title="JSON読込">読込</button>
            <input class="json-file-input" type="file" accept="application/json,.json" hidden />
            <button data-action="reset" class="danger-ghost" title="全消去">消去</button>
          </div>
        </section>
      </div>
    </header>

    <main class="board-main">
      <div class="presentation-toolbar" role="group" aria-label="表示モードと全画面">
        <button data-view="edit" class="view-btn active">✎ 編集</button>
        <button data-view="view" class="view-btn" title="ダブルクリックでFocus / 矢印キーで移動 / Spaceで説明切替 / Escで終了">▶ 表示</button>
        <button data-action="toggle-all-relations" class="all-relations-btn" aria-pressed="false" title="Aggregate / Policy / External System の関係矢印をすべて表示">⇄ 全矢印</button>
        <button data-action="fullscreen" class="fullscreen-btn">⛶ 全画面</button>
        <div class="board-zoom-controls" role="group" aria-label="ボードだけの表示倍率">
          <button data-action="zoom-out" type="button" title="ボードを縮小">−</button>
          <input class="board-zoom-slider" type="range" min="5" max="250" step="1" value="100" aria-label="ボード表示倍率" />
          <output class="board-zoom-value">100%</output>
          <button data-action="zoom-in" type="button" title="ボードを拡大">＋</button>
          <button data-action="zoom-fit" type="button" title="配置されたオブジェクト全体を表示">全体</button>
        </div>
        <button data-action="export-png" class="png-export-btn" title="ボード全体をPNG保存">PNG</button>
        <label class="horizontal-scroll-control" title="ボードを横スクロール">
          <span aria-hidden="true">↔</span>
          <input class="horizontal-scroll-slider" type="range" min="0" max="0" value="0" step="1" aria-label="ボードの横スクロール" />
        </label>
      </div>
      <div class="board-viewport">
        <div class="board-zoom-space">
          <div class="board-canvas">
          <div class="session-title-panel">
            <input class="session-title-input" type="text" maxlength="120" placeholder="セッションタイトル" />
            <div class="session-title-display"></div>
          </div>
          <div class="timeline-guide"><span>EARLIER</span><strong>BUSINESS FLOW / TIME →</strong><span>LATER</span></div>
          <svg class="edge-layer" aria-label="関係線"></svg>
          <div class="note-layer"></div>
          </div>
        </div>
      </div>
    </main>
  </div>

  <div class="presentation-inspector" aria-hidden="true">
    <section class="focus-inspector-panel" tabindex="-1" role="region" aria-label="フォーカスしたオブジェクトの説明">
      <header class="focus-inspector-header">
        <div class="focus-inspector-heading">
          <span class="focus-inspector-kind-icon" aria-hidden="true">⚡</span>
          <div class="focus-inspector-heading-text">
            <div class="focus-inspector-kind"></div>
            <h2 class="focus-inspector-title"></h2>
          </div>
        </div>
        <button data-action="hide-focus-inspector" class="focus-inspector-hide" title="説明カードを閉じる (Space)" aria-label="説明カードを閉じる">×</button>
      </header>
      <div class="focus-inspector-content" aria-live="polite"></div>
      <footer class="focus-inspector-footer">
        <span class="focus-inspector-shortcuts">← ↑ ↓ →：移動　Space：説明　Esc：終了</span>
        <div class="focus-inspector-controls">
          <button data-focus-direction="ArrowLeft" title="左の要素へ">←</button>
          <button data-focus-direction="ArrowUp" title="上の要素へ">↑</button>
          <button data-focus-direction="ArrowDown" title="下の要素へ">↓</button>
          <button data-focus-direction="ArrowRight" title="右の要素へ">→</button>
          <button data-action="exit-presentation-focus" title="フォーカスモードを終了 (Esc)">終了</button>
        </div>
      </footer>
    </section>
  </div>

  <div class="note-modal modal-shell" aria-hidden="true">
    <div class="modal-backdrop" data-action="close-note-modal"></div>
    <section class="modal-panel" role="dialog" aria-modal="true">
      <header class="modal-header">
        <div><div class="modal-kicker">EVENT STORMING ELEMENT</div><h2 class="note-modal-title">要素</h2></div>
        <button class="modal-close" data-action="close-note-modal">×</button>
      </header>
      <div class="note-modal-content"></div>
      <footer class="note-modal-footer"></footer>
    </section>
  </div>

</div>
"""

CSS = r"""
:host {
  --border: color-mix(in srgb, var(--st-text-color) 16%, transparent);
  --muted: color-mix(in srgb, var(--st-text-color) 58%, transparent);
  --accent: var(--st-primary-color);
  --event: #ffb35c;
  --command: #9fd4ff;
  --read: #b8e6ad;
  --focus-stroke-color: #e53935;
  --focus-stroke-width: 3px;
  --toolbar-font-size: 14px;
  --board-zoom: 1;
  --focus-ring-offset: 4px;
  --focus-ring-outer: 8px;
  --relation-stroke-width: 3px;
  display: block;
}
* { box-sizing: border-box; }
button, input, textarea, select { font: inherit; }
button { border: 1px solid var(--border); border-radius: 8px; padding: .44rem .58rem; background: var(--st-background-color); color: var(--st-text-color); cursor: pointer; }
button:hover:not(:disabled) { border-color: var(--accent); }
button:disabled { opacity: .38; cursor: default; }
.primary-btn { background: var(--accent); border-color: var(--accent); color: white; font-weight: 800; }
.danger-ghost:hover { border-color: #b42318; color: #b42318; }
.wide-btn { width: 100%; }

.es-app { width: 100%; color: var(--st-text-color); font-family: var(--st-font); }
.workspace-shell { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 76vh; border: 1px solid var(--border); border-radius: 14px; overflow: hidden; background: var(--st-background-color); }
.control-panel { min-width: 0; border-bottom: 1px solid var(--border); background: color-mix(in srgb, var(--st-secondary-background-color) 72%, var(--st-background-color)); }
.toolbar-main { display: grid; grid-template-columns: 104px minmax(430px, 1fr) minmax(168px, .42fr) minmax(198px, .52fr); align-items: stretch; min-width: 0; }
.board-main { min-width: 0; min-height: 0; position: relative; background: var(--st-background-color); }
.presentation-toolbar { position: absolute; top: 12px; right: 14px; z-index: 30; display: flex; align-items: center; gap: .35rem; padding: .35rem; border: 1px solid var(--border); border-radius: 10px; background: color-mix(in srgb, var(--st-background-color) 92%, transparent); box-shadow: 0 4px 16px rgba(0,0,0,.10); backdrop-filter: blur(4px); }
.presentation-toolbar button { min-height: 34px; font-size: var(--toolbar-font-size); }
.fullscreen-btn { min-width: 86px; }
.png-export-btn { min-width: 46px; padding-inline: .42rem; font-weight: 800; }
.png-export-btn:disabled { opacity: .55; cursor: progress; }
.horizontal-scroll-control { display: flex; align-items: center; gap: .18rem; min-width: 96px; padding: 0 .18rem; color: var(--muted); }
.horizontal-scroll-control > span { flex: 0 0 auto; font-size: 13px; line-height: 1; }
.horizontal-scroll-slider { width: clamp(76px, 9vw, 132px); margin: 0; accent-color: var(--accent); cursor: ew-resize; }
.horizontal-scroll-slider:disabled { opacity: .35; cursor: default; }
/* Zoom is intentionally limited to the board. Inspector and toolbar remain at 100%. */
.board-zoom-controls { display: flex; align-items: center; gap: .18rem; padding: 0 .26rem; border-left: 1px solid var(--border); }
.board-zoom-controls button { min-width: 28px; padding: .2rem .28rem; }
.board-zoom-controls [data-action="zoom-fit"] { min-width: 43px; padding-inline: .3rem; font-weight: 750; }
.board-zoom-slider { width: clamp(60px, 6.5vw, 102px); margin: 0 .18rem; accent-color: var(--accent); cursor: pointer; }
.board-zoom-value { width: 42px; text-align: right; font-size: 12px; font-weight: 750; font-variant-numeric: tabular-nums; }
.es-app.edit-mode .board-zoom-controls { display: none; }
@media (max-width: 760px) { .board-zoom-slider { width: 56px; } .board-zoom-controls { gap: 0; } .board-zoom-controls [data-action="zoom-out"], .board-zoom-controls [data-action="zoom-in"] { display: none; } }

.board-header { min-width: 0; padding: .26rem .34rem; border-right: 1px solid var(--border); background: var(--st-background-color); }
.board-brand { display: flex; gap: .28rem; align-items: center; height: 100%; min-width: 0; }
.board-brand strong { min-width: 0; font-size: var(--toolbar-font-size); line-height: 1.05; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.board-brand-mark { width: 24px; height: 24px; flex: 0 0 24px; border-radius: 6px; display: grid; place-items: center; background: var(--accent); color: white; font-size: 10px; font-weight: 900; }
.view-btn.active { border-color: var(--accent); box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 15%, transparent); font-weight: 800; }
.all-relations-btn.active { border-color: var(--focus-stroke-color); color: var(--focus-stroke-color); box-shadow: 0 0 0 2px color-mix(in srgb, var(--focus-stroke-color) 15%, transparent); font-weight: 800; }
.es-app.all-relations-visible .selected-note.semantic-node .node-icon { outline: none !important; }

.panel-section { min-width: 0; padding: .28rem .46rem; border-right: 1px solid var(--border); }
.creator-section { min-width: 0; }
.creator-row { display: grid; grid-template-columns: auto minmax(0, 1fr); align-items: center; gap: .42rem; }
.panel-heading, .legend-label { margin: 0; font-size: var(--toolbar-font-size); font-weight: 850; letter-spacing: 0; text-transform: none; color: var(--muted); white-space: nowrap; }
.field-label, .editor-field { display: flex; flex-direction: column; gap: .22rem; color: var(--muted); font-size: 11px; font-weight: 750; }
.new-note-kind, .new-note-title, .new-note-text, .field-label select, .editor-field input, .editor-field textarea, .editor-field select { width: 100%; border: 1px solid var(--border); border-radius: 7px; padding: .3rem .43rem; background: var(--st-background-color); color: var(--st-text-color); }
.creator-controls { display: grid; grid-template-columns: minmax(132px, 165px) minmax(125px, .8fr) minmax(170px, 1.25fr) 62px; gap: .28rem; align-items: center; min-width: 0; }
.creator-controls .new-note-kind, .creator-controls .new-note-title, .creator-controls .new-note-text, .creator-controls .primary-btn { margin: 0; height: 30px; min-height: 30px; }
.creator-controls .new-note-text { resize: none; overflow: hidden; }
.creator-controls .primary-btn { min-width: 0; padding: .2rem .35rem; }
.legend-inline { display: flex; align-items: center; gap: .42rem; min-width: 0; margin-top: .24rem; padding-top: .2rem; border-top: 1px solid color-mix(in srgb, var(--border) 70%, transparent); }
.legend-items { display: flex; flex-wrap: nowrap; gap: .14rem .36rem; align-items: center; min-width: 0; overflow: hidden; font-size: var(--toolbar-font-size); line-height: 1.05; color: var(--muted); }
.legend-items > span { white-space: nowrap; }
.swatch { display: inline-block; width: 12px; height: 9px; margin-right: .2rem; border: 1px solid rgba(0,0,0,.18); vertical-align: 0; }
.swatch.event { background: var(--event); }.swatch.command { background: var(--command); }.swatch.read { background: var(--read); }
.compact-panel { display: grid; grid-template-rows: 20px 30px; align-content: center; gap: .12rem; }
.compact-panel-head { display: flex; align-items: center; justify-content: space-between; gap: .35rem; min-width: 0; }
.selected-note-summary { min-width: 0; max-width: 94px; padding: 0; border: 0; background: transparent; color: var(--muted); font-size: var(--toolbar-font-size); line-height: 1.05; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.selected-note-summary.has-selection { color: var(--st-text-color); }
.z-order-actions { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: .18rem; }
.utility-actions { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: .18rem; }
.z-order-actions button, .utility-actions button { min-width: 0; min-height: 30px; padding: .12rem .2rem; border-radius: 6px; font-size: var(--toolbar-font-size); line-height: 1; white-space: nowrap; }
.stats { min-width: 0; color: var(--muted); font-size: var(--toolbar-font-size); line-height: 1.05; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

/* Use the same typography as the Edit / View controls while keeping a single-row toolbar. */
.control-panel,
.control-panel button,
.control-panel input,
.control-panel textarea,
.control-panel select { font-size: var(--toolbar-font-size); line-height: 1.05; }

.board-viewport { height: 78vh; min-height: 590px; overflow: auto; cursor: grab; background: linear-gradient(to right, rgba(70,70,70,.055) 1px, transparent 1px), linear-gradient(to bottom, rgba(70,70,70,.055) 1px, transparent 1px), var(--st-background-color); background-size: 24px 24px; }
.board-viewport.is-panning { cursor: grabbing; user-select: none; }
.board-viewport.is-panning * { cursor: grabbing !important; }
.board-zoom-space { position: relative; width: 2850px; height: 1800px; translate: var(--board-pan-x, 0px) var(--board-pan-y, 0px); }
.board-canvas { width: 2850px; height: 1800px; position: relative; user-select: none; transform: scale(var(--board-zoom)); transform-origin: top left; }

.session-title-panel { position: absolute; top: 22px; left: 30px; z-index: 7; }
.session-title-input {
  width: min(990px, 82.5vw);
  padding: .45rem .6rem;
  border: 1px dashed var(--border);
  border-radius: 8px;
  background: color-mix(in srgb, var(--st-background-color) 90%, transparent);
  font-size: 21px;
  line-height: 1.2;
  font-weight: 850;
  letter-spacing: 0;
  color: var(--st-text-color);
}
.session-title-display {
  width: min(990px, 82.5vw);
  padding: .45rem .6rem;
  font-size: 21px;
  line-height: 1.2;
  font-weight: 850;
  letter-spacing: 0;
  color: var(--st-text-color);
}
.es-app.edit-mode .session-title-display { display: none; }.es-app.view-mode .session-title-input { display: none; }
.timeline-guide { position: absolute; top: 83px; left: 32px; right: 45px; height: 18px; display: flex; align-items: center; justify-content: space-between; color: var(--muted); font-size: 9px; z-index: 0; }
.timeline-guide::before { content: ""; position: absolute; left: 0; right: 0; top: 50%; border-top: 1px dashed color-mix(in srgb, var(--st-text-color) 20%, transparent); z-index: -1; }
.timeline-guide > * { background: var(--st-background-color); padding: 0 .45rem; }
.edge-layer, .note-layer { position: absolute; inset: 0; }
.edge-layer { width: 100%; height: 100%; z-index: 1; pointer-events: none; overflow: visible; }
.note-layer { z-index: 3; pointer-events: none; }

.business-note { position: absolute; width: 220px; min-height: 150px; height: auto; color: #171717; border: 1px solid rgba(0,0,0,.18); border-radius: 3px; box-shadow: 0 7px 16px rgba(0,0,0,.14); overflow: visible; pointer-events: auto; transition: filter .18s ease, opacity .18s ease, transform .13s ease, box-shadow .13s ease; }
.business-note[data-kind="domain_event"] { background: var(--event); }.business-note[data-kind="command"] { background: var(--command); }.business-note[data-kind="read_model"] { background: var(--read); }
.business-note:hover { transform: translateY(-1px); box-shadow: 0 10px 22px rgba(0,0,0,.18); }
.note-handle { height: 25px; display: flex; justify-content: space-between; align-items: center; padding: 0 .32rem 0 .5rem; border-bottom: 1px dashed rgba(0,0,0,.17); cursor: grab; color: rgba(0,0,0,.55); font-size: 10px; }
.note-handle:active, .node-icon:active { cursor: grabbing; }
.note-delete, .node-delete { width: 24px; height: 22px; padding: 0; border: none; background: transparent; color: rgba(0,0,0,.52); font-weight: 900; }
.note-delete:hover, .node-delete:hover { color: #a00; }
.note-title { min-height: 31px; padding: .33rem .62rem; display: flex; gap: .4rem; align-items: flex-start; background: rgba(255,255,255,.26); border-bottom: 1px solid rgba(0,0,0,.10); }
.note-title-text { flex: 1; min-width: 0; overflow: visible; text-overflow: clip; white-space: normal; overflow-wrap: anywhere; word-break: break-word; font-weight: 850; font-size: 14px; line-height: 1.32; }
.note-type-badge { font-size: 9px; border: 1px solid rgba(0,0,0,.24); border-radius: 999px; padding: .06rem .3rem; white-space: nowrap; }
.note-body { min-height: 93px; padding: .62rem .72rem; overflow: auto; white-space: pre-wrap; overflow-wrap: anywhere; user-select: text; font-size: 14px; line-height: 1.42; outline: none; color: #171717; }

.semantic-node { position: absolute; width: 164px; height: 122px; display: flex; flex-direction: column; align-items: center; justify-content: center; pointer-events: auto; overflow: visible; transition: filter .18s ease, opacity .18s ease, transform .13s ease; }
.semantic-node:hover { transform: translateY(-2px); }
.node-icon { display: grid; place-items: center; width: 82px; height: 75px; font-size: 60px; line-height: 1; cursor: grab; filter: drop-shadow(0 4px 4px rgba(0,0,0,.16)); }
.node-title { width: 160px; max-width: 160px; padding: .24rem .46rem; border-radius: 7px; background: color-mix(in srgb, var(--st-background-color) 92%, transparent); border: 1px solid var(--border); color: var(--st-text-color); font-size: 14px; font-weight: 850; line-height: 1.32; text-align: center; overflow: visible; text-overflow: clip; white-space: normal; overflow-wrap: anywhere; word-break: break-word; }
.node-delete { position: absolute; top: 2px; right: 8px; border-radius: 50%; background: color-mix(in srgb, var(--st-background-color) 90%, transparent); opacity: 0; transition: opacity .12s ease; }
.semantic-node:hover .node-delete, .semantic-node.selected-note .node-delete { opacity: 1; }

.selected-note.business-note { outline: 3px solid #fff; outline-offset: 2px; box-shadow: 0 0 0 5px #111, 0 12px 28px rgba(0,0,0,.22); }
.selected-note.semantic-node .node-icon { border-radius: 18px; outline: var(--focus-stroke-width) solid var(--focus-stroke-color); outline-offset: 4px; }
/* Presentation focus is independent of selection and relation highlighting. */
/* Fractional box-shadow spreads do not snap to integer CSS border widths.
   Counter-scale both ring radii so the outer red band remains 4 screen pixels. */
.presentation-focus.business-note { outline: none; transition: filter .18s ease, opacity .18s ease, transform .13s ease; box-shadow: 0 0 0 var(--focus-ring-offset) rgba(255,255,255,.96), 0 0 0 var(--focus-ring-outer) #e53935, 0 10px 24px rgba(0,0,0,.2); }
.presentation-focus.semantic-node .node-icon { border-radius: 16px; outline: none; box-shadow: 0 0 0 var(--focus-ring-offset) rgba(255,255,255,.96), 0 0 0 var(--focus-ring-outer) #e53935; }

.es-app.view-mode .focus-mode-hint { display: inline; }
.focus-mode-hint { display: none; color: var(--muted); font-size: 11px; white-space: nowrap; }
.presentation-inspector { display: none; position: fixed; inset: 0; z-index: 10001; pointer-events: none; }
.presentation-inspector.open { display: block; }
/* This entire layer is a sibling of the scaled board, never a scaled child. */
.focus-inspector-panel { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: min(600px, 86vw); max-height: 66vh; display: flex; flex-direction: column; overflow: hidden; border: 1px solid #aeb8c3; border-radius: 14px; background: #eef1f4; color: #182431; font-size: 16px; box-shadow: 0 18px 48px rgba(15,23,42,.30); pointer-events: auto; }
.focus-inspector-panel:focus { outline: none; }
.focus-inspector-panel.placement-right { left: auto; right: 16px; transform: translateY(-50%); }
.focus-inspector-panel.placement-left { left: 16px; transform: translateY(-50%); }
.focus-inspector-header { display: flex; align-items: center; justify-content: space-between; gap: .8rem; padding: .85rem 1rem; border-bottom: 1px solid rgba(19,38,58,.16); background: #ffd092; color: #17212e; }
.focus-inspector-panel[data-kind="domain_event"] .focus-inspector-header { background: #ffc678; }
.focus-inspector-panel[data-kind="command"] .focus-inspector-header { background: #9fd4ff; }
.focus-inspector-panel[data-kind="read_model"] .focus-inspector-header { background: #b8e6ad; }
/* Event Storming visual language: Event=orange, Command=blue, Read Model=green,
   Aggregate=yellow, Policy=purple, External System=pink, Hot Spot=red. */
.focus-inspector-panel[data-kind="aggregate"] .focus-inspector-header { background: #ffe081; }
.focus-inspector-panel[data-kind="policy"] .focus-inspector-header { background: #c7a5f0; }
.focus-inspector-panel[data-kind="actor"] .focus-inspector-header { background: #f5e7bc; }
.focus-inspector-panel[data-kind="hotspot"] .focus-inspector-header { background: #ffb0ad; }
.focus-inspector-panel[data-kind="external_system"] .focus-inspector-header { background: #f5b5d5; }
.focus-inspector-panel[data-kind="insight"] .focus-inspector-header { background: #f6e7a2; }
.focus-inspector-heading { display: flex; align-items: center; gap: .85rem; min-width: 0; }
.focus-inspector-heading-text { min-width: 0; }
.focus-inspector-kind-icon { width: 48px; height: 48px; flex: 0 0 48px; display: grid; place-items: center; border-radius: 12px; background: rgba(255,255,255,.62); box-shadow: inset 0 0 0 1px rgba(30,41,59,.12); font-size: 30px; line-height: 1; }
.focus-inspector-kind { font-size: 12px; font-weight: 850; color: #364153; letter-spacing: .04em; }
.focus-inspector-title { margin: .18rem 0 0; font-size: 21px; font-weight: 800; line-height: 1.35; overflow-wrap: anywhere; }
.focus-inspector-hide { flex: 0 0 auto; width: 32px; height: 32px; padding: 0; font-size: 20px; background: rgba(255,255,255,.8); color: #17212e; border: 1px solid rgba(30,41,59,.16); }
.focus-inspector-content { min-height: 72px; padding: 1rem 1.15rem; overflow: auto; line-height: 1.65; font-size: 16px; overflow-wrap: anywhere; }
.focus-inspector-field + .focus-inspector-field { margin-top: .85rem; }
.focus-inspector-label { font-size: 12px; font-weight: 800; color: #526171; margin-bottom: .22rem; }
.focus-inspector-value { white-space: pre-wrap; overflow-wrap: anywhere; }
.focus-inspector-muted { color: #657386; }
.focus-inspector-code { margin: .35rem 0 0; padding: .75rem; max-height: 180px; overflow: auto; background: #dfe5ea; border-radius: 7px; white-space: pre-wrap; font-size: 14px; }
.focus-inspector-footer { border-top: 1px solid #c9d1da; background: #e5e9ee; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: .5rem; padding: .65rem 1rem; }
.focus-inspector-shortcuts { font-size: 11px; color: #526171; }
.focus-inspector-controls { display: flex; align-items: center; gap: .3rem; }
.focus-inspector-controls button { min-width: 32px; padding: .3rem .45rem; background: #fff; color: #233043; border: 1px solid #adb8c6; }
@media (max-width: 760px) { .focus-mode-hint { display: none !important; }  .focus-inspector-panel, .focus-inspector-panel.placement-left, .focus-inspector-panel.placement-right { top: auto; bottom: 12px; left: 50%; right: auto; transform: translateX(-50%); width: 94vw; max-height: 48vh; } .focus-inspector-shortcuts { display: none; } }

.focus-dimmed { filter: blur(3px) grayscale(.18); opacity: .20; }
.focus-related { filter: none; opacity: 1; }
.semantic-edge { stroke: var(--focus-stroke-color); stroke-width: var(--relation-stroke-width); fill: none; pointer-events: none; }
.semantic-arrow-head { fill: var(--focus-stroke-color); }

.modal-shell { display: none; position: fixed; inset: 0; z-index: 10000; }.modal-shell.open { display: block; }
.modal-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,.58); backdrop-filter: blur(3px); }
.modal-panel { position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); width: min(980px, 92vw); max-height: 90vh; overflow: auto; background: var(--st-background-color); color: var(--st-text-color); border: 1px solid var(--border); border-radius: 15px; box-shadow: 0 30px 80px rgba(0,0,0,.36); padding: 1.1rem 1.2rem 1.2rem; }
.small-modal { width: min(620px, 92vw); }.modal-header { display: flex; justify-content: space-between; align-items: start; gap: 1rem; border-bottom: 1px solid var(--border); padding-bottom: .7rem; }.modal-kicker { color: var(--muted); font-size: 9px; letter-spacing: .13em; font-weight: 850; }.modal-header h2 { margin: .12rem 0 0; font-size: 1.25rem; }.modal-close { width: 38px; height: 38px; padding: 0; font-size: 22px; }.note-modal-content { padding-top: .9rem; }.note-modal-footer, .modal-actions { display: flex; align-items: center; gap: .48rem; padding-top: .9rem; }.spacer { flex: 1; }
.editor-grid { display: grid; grid-template-columns: 1fr 1fr; gap: .75rem; }.editor-field.full { grid-column: 1 / -1; }.editor-field textarea { min-height: 130px; resize: vertical; }.editor-field textarea.tall { min-height: 220px; }
.relation-grid { display: grid; grid-template-columns: 1fr 1fr; gap: .8rem; margin-top: .8rem; }.relation-column { border: 1px solid var(--border); border-radius: 10px; padding: .7rem; }.relation-column h3 { margin: 0 0 .5rem; font-size: 12px; }.relation-options { display: grid; gap: .35rem; max-height: 260px; overflow: auto; }.relation-option { display: flex; gap: .45rem; align-items: flex-start; padding: .4rem; border-radius: 7px; background: color-mix(in srgb, var(--st-secondary-background-color) 52%, transparent); font-size: 12px; }.relation-option input { margin-top: .16rem; }.relation-empty { color: var(--muted); font-size: 11px; }
.render-status { color: var(--muted); font-size: 11px; margin-top: .5rem; }
.relation-viewer { display: grid; gap: .85rem; }.mermaid-preview { min-height: 280px; padding: 1rem; border: 1px solid var(--border); border-radius: 12px; background: color-mix(in srgb, var(--st-secondary-background-color) 38%, var(--st-background-color)); overflow: auto; }.mermaid-preview svg { display: block; max-width: 100%; height: auto; margin: 0 auto; }.relation-rule-view { padding: .8rem .9rem; border: 1px solid var(--border); border-radius: 10px; background: color-mix(in srgb, var(--st-secondary-background-color) 42%, var(--st-background-color)); white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.55; }.relation-rule-view strong { display: block; margin-bottom: .35rem; }
.hotspot-memo-view { white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.55; }
.preview-error { padding: .8rem; border: 1px solid #d66; border-radius: 8px; color: #c33; white-space: pre-wrap; }

.es-app.view-mode .control-panel { display: none; }.es-app.view-mode .workspace-shell { grid-template-rows: minmax(0, 1fr); }.es-app.view-mode .board-viewport { height: 90vh; }.es-app.view-mode .note-handle, .es-app.view-mode .note-delete, .es-app.view-mode .node-delete { display: none !important; }.es-app.view-mode .note-body { cursor: default; }
.es-app:fullscreen .workspace-shell { width: 100vw; height: 100vh; min-height: 0; border: 0; border-radius: 0; }
/* In fullscreen, keep the mode toolbar inside the board row so it never covers the edit controls above. */
.es-app:fullscreen .presentation-toolbar { position: absolute; top: 12px; right: 14px; }
.es-app:fullscreen .board-viewport { height: 100%; min-height: 0; }
@media (max-width: 900px) {
  .toolbar-main { grid-template-columns: 82px minmax(360px, 1fr) 154px 178px; }
  .board-brand strong { display: none; }
  .board-header { display: grid; place-items: center; }
  .board-brand { justify-content: center; }

  .relation-grid, .editor-grid { grid-template-columns: 1fr; }.editor-field.full { grid-column: auto; }
}
@media (max-width: 720px) {
  .toolbar-main { display: block; }
  .board-header, .creator-section, .z-order-panel, .utilities { border-right: 0; border-bottom: 1px solid var(--border); }
  .creator-row { grid-template-columns: 1fr; gap: .22rem; }
  .creator-controls { grid-template-columns: 1fr 1fr; }
  .creator-controls .new-note-text { grid-column: 1 / -1; }
  .creator-controls .primary-btn { grid-column: 1 / -1; }
  .legend-inline { align-items: flex-start; }.legend-items { flex-wrap: wrap; overflow: visible; }
}
/* Miro-style single-line palette: the old multi-field creation form remains optional. */
.toolbar-main { grid-template-columns: 104px minmax(580px, 1fr) minmax(150px, .24fr) minmax(198px, .29fr); }
.creator-section { display: flex; align-items: center; gap: .42rem; position: relative; overflow: visible; }
.object-palette { min-width: 0; width: 100%; display: flex; align-items: center; justify-content: flex-start; gap: .18rem; }
.palette-item { min-width: 0; flex: 1 1 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; padding: .18rem .14rem; height: 54px; border: 1px solid transparent; border-radius: 7px; background: transparent; cursor: grab; font-size: 10px !important; line-height: 1.05 !important; white-space: nowrap; touch-action: none; }
.palette-item:hover, .palette-item:focus-visible { background: color-mix(in srgb, var(--st-primary-color) 12%, var(--st-background-color)); border-color: var(--border); }
.palette-item:active { cursor: grabbing; }
.palette-symbol { display: grid; place-items: center; width: 28px; height: 28px; font-size: 22px; line-height: 1; }
.palette-event, .palette-command, .palette-read { border: 1px solid rgba(0,0,0,.22); border-radius: 2px; color: #343434; font-size: 16px; }
.palette-event { background: var(--event); }.palette-command { background: var(--command); }.palette-read { background: var(--read); }
.advanced-create-menu { flex: 0 0 auto; font-size: 11px; z-index: 65; }
.advanced-create-menu > summary { list-style: none; white-space: nowrap; cursor: pointer; padding: .35rem .3rem; border: 1px solid var(--border); border-radius: 6px; background: var(--st-background-color); }
.advanced-create-menu > summary::-webkit-details-marker { display: none; }
.advanced-create-menu[open] .creator-controls { position: absolute; right: 0; top: calc(100% + 5px); z-index: 75; width: min(540px, 93vw); display: grid; grid-template-columns: 1fr 1fr; gap: .48rem; padding: .7rem; border: 1px solid var(--border); border-radius: 9px; background: var(--st-background-color); box-shadow: 0 12px 30px rgba(0,0,0,.24); }
.advanced-create-menu .new-note-text { resize: vertical; min-height: 62px; height: 62px !important; grid-column: 1 / -1; overflow: auto; }
.advanced-create-menu .creator-controls .primary-btn { grid-column: 1 / -1; }
.advanced-create-menu[open] .creator-controls .new-note-kind, .advanced-create-menu[open] .creator-controls .new-note-title { height: 34px; }
.es-app.edit-mode .board-zoom-controls { display: flex; }
.board-zoom-slider { width: clamp(60px, 6.5vw, 102px); }
.business-note { width: 196px; height: 196px; min-height: 196px; display: flex; flex-direction: column; cursor: grab; touch-action: none; }
.business-note .note-handle { flex: 0 0 24px; cursor: grab; }
.business-note .note-title { flex: 0 0 auto; }
.business-note .note-body { min-height: 0; flex: 1 1 auto; overflow: auto; cursor: text; touch-action: none; }
.business-note.is-note-dragging, .business-note.is-note-dragging * { cursor: grabbing !important; user-select: none !important; }
.semantic-node { cursor: grab; touch-action: none; }
.semantic-node.is-note-dragging, .semantic-node.is-note-dragging * { cursor: grabbing !important; user-select: none !important; }
.board-viewport.palette-drop-target { box-shadow: inset 0 0 0 3px var(--st-primary-color); }
.palette-drag-ghost { position: fixed; z-index: 999; transform: translate(-50%,-50%); pointer-events: none; width: 102px; height: 102px; display: grid; place-items: center; padding: 10px; text-align: center; line-height: 1.3; font-size: 13px; font-weight: 850; border: 1px solid rgba(0,0,0,.2); border-radius: 5px; color: #171717; background: var(--ghost-color); box-shadow: 0 8px 26px rgba(0,0,0,.27); opacity: .85; }
.palette-drag-node { width: 118px; height: 66px; border-radius: 12px; }
@media(max-width: 1280px) { .toolbar-main { grid-template-columns: 72px minmax(550px,1fr) 135px 172px; }.board-brand strong { display: none; }.board-header { display: grid; place-items: center; } .palette-item { font-size: 9px !important; } }
@media(max-width: 1000px) { .toolbar-main { grid-template-columns: minmax(0,1fr) auto; }.board-header { display: none; }.creator-section { grid-column: 1/-1; }.z-order-panel, .utilities { grid-row: 2; } .z-order-panel { grid-column: 1; }.utilities { grid-column: 2; } }
@media(max-width: 720px) { .toolbar-main { display: block; }.creator-section { padding: .3rem; }.object-palette { overflow-x: auto; }.palette-item { flex: 0 0 63px; }.advanced-create-menu[open] .creator-controls { right: 4px; top: 100%; }.presentation-toolbar { max-width: calc(100% - 14px); overflow-x: auto; right: 7px; } }

"""

JS = r"""
const NOTE_W = 196;
const NOTE_H = 196;
const MIN_ZOOM = 0.05;
const MAX_ZOOM = 2.5;
const NODE_W = 164;
const NODE_H = 122;

const KINDS = {
  domain_event: {label: "Domain Event", business: true, color: "#ffb35c", icon: "⚡"},
  command: {label: "Command", business: true, color: "#9fd4ff", icon: "📣"},
  read_model: {label: "Read Model", business: true, color: "#b8e6ad", icon: "📊"},
  aggregate: {label: "Aggregate", node: true, icon: "🏛️"},
  policy: {label: "Policy", node: true, icon: "⚙️"},
  actor: {label: "Actor", node: true, icon: "👤"},
  hotspot: {label: "Hot Spot", node: true, icon: "🔥"},
  external_system: {label: "External System", node: true, icon: "📡"},
};
function kindInfo(kind) { return KINDS[kind] || KINDS.domain_event; }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function uid(prefix) { return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`; }
function escapeHtml(value) {
  return String(value ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}
function uniqueIds(values) { return [...new Set((Array.isArray(values) ? values : []).filter(Boolean))]; }

function normalizeBoard(board) {
  const src = board && typeof board === "object" ? board : {};
  const notes = Array.isArray(src.notes) ? src.notes.filter(note => KINDS[note.eventKind || note.kind || "domain_event"]).map(note => {
    const eventKind = note.eventKind || note.kind || "domain_event";
    const info = kindInfo(eventKind);
    return {
      id: note.id || uid("note"),
      title: note.title || "",
      text: note.text || "",
      eventKind,
      color: info.business ? info.color : "",
      x: Number(note.x ?? 90),
      y: Number(note.y ?? 140),
      w: info.business ? NOTE_W : NODE_W,
      h: info.business ? NOTE_H : NODE_H,
      inputIds: uniqueIds(note.inputIds),
      outputIds: uniqueIds(note.outputIds),
      ruleText: String(note.ruleText || ""),
    };
  }) : [];
  const noteIds = new Set(notes.map(n => n.id));
  for (const note of notes) {
    note.inputIds = note.inputIds.filter(id => noteIds.has(id) && id !== note.id);
    note.outputIds = note.outputIds.filter(id => noteIds.has(id) && id !== note.id);
  }

  return {title: String(src.title || ""), notes};
}

let mermaidPromise = null;
let htmlToImagePromise = null;

async function getHtmlToImage() {
  if (!htmlToImagePromise) {
    htmlToImagePromise = import("https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/+esm");
  }
  return htmlToImagePromise;
}

function mermaidLabel(value) {
  return String(value ?? "")
    .replaceAll("\\", "\\\\")
    .replaceAll('"', "'")
    .replaceAll("\r", "")
    .replaceAll("\n", "<br/>");
}
async function renderMermaidFlow(source, host) {
  host.innerHTML = `<div class="render-status">Mermaid フローチャートを描画しています…</div>`;
  try {
    if (!mermaidPromise) {
      mermaidPromise = import("https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs").then(module => {
        const mermaid = module.default;
        mermaid.initialize({startOnLoad:false, securityLevel:"strict", theme:"default"});
        return mermaid;
      });
    }
    const mermaid = await mermaidPromise;
    const renderId = `relation_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const rendered = await mermaid.render(renderId, source);
    host.innerHTML = rendered.svg;
  } catch (err) {
    host.innerHTML = `<div class="preview-error">Mermaid の描画に失敗しました。<br>${escapeHtml(err?.message || String(err))}</div>`;
  }
}

export default function(component) {
  const {parentElement, data, setStateValue} = component;

  if (parentElement.__esApp) {
    const app = parentElement.__esApp;
    const incoming = normalizeBoard(data?.board);
    const serialized = JSON.stringify(incoming);
    if (serialized !== app.lastSyncedSerialized && serialized !== JSON.stringify(app.board)) {
      app.board = clone(incoming);
      app.history = [];
      app.future = [];
      if (app.selectedNoteId && !app.noteById(app.selectedNoteId)) app.selectedNoteId = null;
      if (app.presentationFocusId && !app.noteById(app.presentationFocusId)) app.closePresentationFocus();
      app.render();
      if(app.presentationFocusId && app.presentationInspectorOpen)app.refreshFocusInspector();
    }
    return;
  }

  const root = parentElement.querySelector(".es-app");
  const canvas = root.querySelector(".board-canvas");
  const zoomSpace = root.querySelector(".board-zoom-space");
  const zoomSlider = root.querySelector(".board-zoom-slider");
  const zoomValue = root.querySelector(".board-zoom-value");
  const viewport = root.querySelector(".board-viewport");
  const noteLayer = root.querySelector(".note-layer");
  const edgeLayer = root.querySelector(".edge-layer");
  const titleInput = root.querySelector(".session-title-input");
  const titleDisplay = root.querySelector(".session-title-display");
  const newKind = root.querySelector(".new-note-kind");
  const newTitle = root.querySelector(".new-note-title");
  const newText = root.querySelector(".new-note-text");
  const stats = root.querySelector(".stats");
  const selectedSummary = root.querySelector(".selected-note-summary");
  const noteModal = root.querySelector(".note-modal");
  const noteModalTitle = root.querySelector(".note-modal-title");
  const noteModalContent = root.querySelector(".note-modal-content");
  const noteModalFooter = root.querySelector(".note-modal-footer");
  const presentationInspector = root.querySelector(".presentation-inspector");
  const focusInspectorPanel = root.querySelector(".focus-inspector-panel");
  const focusInspectorKind = root.querySelector(".focus-inspector-kind");
  const focusInspectorIcon = root.querySelector(".focus-inspector-kind-icon");
  const focusInspectorTitle = root.querySelector(".focus-inspector-title");
  const focusInspectorContent = root.querySelector(".focus-inspector-content");
  const fileInput = root.querySelector(".json-file-input");
  const horizontalScrollSlider = root.querySelector(".horizontal-scroll-slider");
  const allRelationsButton = root.querySelector('[data-action="toggle-all-relations"]');
  const zButtons = {
    stepFront: root.querySelector('[data-action="step-front"]'),
    stepBack: root.querySelector('[data-action="step-back"]'),
    front: root.querySelector('[data-action="bring-front"]'),
    back: root.querySelector('[data-action="send-back"]'),
  };

  function updateHorizontalScrollSlider() {
    if (!horizontalScrollSlider) return;
    const max = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
    horizontalScrollSlider.max = String(Math.round(max));
    horizontalScrollSlider.value = String(Math.min(Math.round(viewport.scrollLeft), Math.round(max)));
    horizontalScrollSlider.disabled = max <= 0;
  }

  const app = {
    board: clone(normalizeBoard(data?.board)),
    mode: "move",
    viewMode: "edit",
    history: [],
    future: [],
    selectedNoteId: null,
    activeNoteId: null,
    presentationFocusId: null,
    presentationInspectorOpen: false,
    boardZoom: 1,
    boardZoomTarget: 1,
    panOffsetX: 0,
    panOffsetY: 0,
    showAllRelations: false,
    lastSyncedSerialized: "",

    noteById(id) { return this.board.notes.find(note => note.id === id); },
    updateZoomSpace() {
      zoomSpace.style.width=`${Math.ceil(canvas.offsetWidth*this.boardZoom)}px`;
      zoomSpace.style.height=`${Math.ceil(canvas.offsetHeight*this.boardZoom)}px`;
      this.setPanOffset(this.panOffsetX,this.panOffsetY);
    },
    // Native scroll handles a large board. Offsets permit grab-and-drag even when
    // the zoomed board is narrower or shorter than the viewport scroll area.
    setPanOffset(x,y) {
      const limits=(extent,view,value)=>{
        if(extent>=view)return 0;
        const visible=Math.min(extent,96);
        return Math.max(visible-extent,Math.min(view-visible,value));
      };
      this.panOffsetX=limits(canvas.offsetWidth*this.boardZoom,viewport.clientWidth,x);
      this.panOffsetY=limits(canvas.offsetHeight*this.boardZoom,viewport.clientHeight,y);
      root.style.setProperty("--board-pan-x",`${this.panOffsetX}px`);
      root.style.setProperty("--board-pan-y",`${this.panOffsetY}px`);
    },
    // The logical board never changes when the viewport zoom changes.
    // anchor is either a client-space cursor point or the viewport center.
    setBoardZoom(value, anchor=null) {
      const numeric=Number(value);
      if(!Number.isFinite(numeric))return;
      this.boardZoomTarget=Math.max(MIN_ZOOM,Math.min(MAX_ZOOM,numeric));
      const next=Math.round(this.boardZoomTarget*100)/100;
      const old=this.boardZoom;
      if(next===old)return;
      const box=viewport.getBoundingClientRect();
      const vx=anchor && Number.isFinite(anchor.clientX) ? anchor.clientX-box.left : viewport.clientWidth/2;
      const vy=anchor && Number.isFinite(anchor.clientY) ? anchor.clientY-box.top : viewport.clientHeight/2;
      const logicalX=(viewport.scrollLeft+vx-this.panOffsetX)/old;
      const logicalY=(viewport.scrollTop+vy-this.panOffsetY)/old;
      this.boardZoom=next;
      root.style.setProperty("--board-zoom",String(next));
      // Preserve a constant on-screen width for focus rings and relation strokes.
      root.style.setProperty("--focus-ring-offset",`${4/next}px`);
      root.style.setProperty("--focus-ring-outer",`${8/next}px`);
      root.style.setProperty("--relation-stroke-width",`${3/next}px`);
      zoomSpace.style.width=`${Math.ceil(canvas.offsetWidth*next)}px`;
      zoomSpace.style.height=`${Math.ceil(canvas.offsetHeight*next)}px`;
      const extentX=canvas.offsetWidth*next,extentY=canvas.offsetHeight*next;
      const scrollX=extentX>viewport.clientWidth ? logicalX*next-vx : 0;
      const scrollY=extentY>viewport.clientHeight ? logicalY*next-vy : 0;
      this.setPanOffset(extentX<=viewport.clientWidth ? vx-logicalX*next : 0,
                        extentY<=viewport.clientHeight ? vy-logicalY*next : 0);
      viewport.scrollLeft=Math.max(0,scrollX);
      viewport.scrollTop=Math.max(0,scrollY);
      zoomSlider.value=String(Math.round(next*100));
      zoomValue.textContent=`${Math.round(next*100)}%`;
      this.renderEdges();
      requestAnimationFrame(()=>{
        updateHorizontalScrollSlider();
        if(!anchor?.clientX && this.presentationFocusId)this.ensureFocusVisible();
      });
    },
    // Screen/client coordinates -> unscaled board coordinates. Used by palette DnD.
    clientToBoard(clientX,clientY) {
      const r=canvas.getBoundingClientRect();
      return {x:(clientX-r.left)/this.boardZoom,y:(clientY-r.top)/this.boardZoom};
    },
    fitBoardToView() {
      // The board has a minimum canvas size; fit the actual note extent instead.
      let maxX=1040,maxY=180;
      for(const note of this.board.notes){
        const r=this.noteRect(note);
        maxX=Math.max(maxX,r.x+r.w+34);
        maxY=Math.max(maxY,r.y+r.h+40);
      }
      const factor=Math.min(1,(viewport.clientWidth-38)/maxX,(viewport.clientHeight-38)/maxY);
      this.setBoardZoom(Math.floor(Math.max(MIN_ZOOM,factor)*100)/100);
      viewport.scrollTo({left:0,top:0,behavior:"instant"});
      requestAnimationFrame(()=>this.ensureFocusVisible());
    },

    /* Find the nearest note in the requested spatial direction.
       Candidates within a 50-degree cone have priority; use the entire
       directional half-plane only if the cone is empty. */
    findDirectionalNeighbor(id, direction) {
      const current=this.noteById(id);
      if(!current)return null;
      const center=this.center(this.noteRect(current));
      const horizontal=direction==="ArrowLeft"||direction==="ArrowRight";
      const sign=direction==="ArrowRight"||direction==="ArrowDown"?1:-1;
      const candidates=this.board.notes.filter(n=>n.id!==id).map(n=>{
        const other=this.center(this.noteRect(n));
        const axial=sign*(horizontal?other.x-center.x:other.y-center.y);
        const lateral=Math.abs(horizontal?other.y-center.y:other.x-center.x);
        return {note:n,axial,lateral};
      }).filter(c=>c.axial>0);
      if(!candidates.length)return null;
      const cone=candidates.filter(c=>c.lateral<=c.axial*Math.tan(50*Math.PI/180));
      const pool=cone.length?cone:candidates;
      pool.sort((a,b)=>(a.axial+2*a.lateral)-(b.axial+2*b.lateral)||a.axial-b.axial||a.note.id.localeCompare(b.note.id));
      return pool[0].note;
    },

    refreshPresentationFocus() {
      noteLayer.querySelectorAll(".board-item").forEach(el=>{
        el.classList.toggle("presentation-focus",this.viewMode==="view" && el.dataset.noteId===this.presentationFocusId);
      });
    },
    openPresentationFocus(id) {
      if(this.viewMode!=="view")return;
      const note=this.noteById(id);if(!note)return;
      // A presentation selection must not activate relation-dimming.
      this.selectedNoteId=null;
      this.refreshZControls();this.renderEdges();
      this.presentationFocusId=note.id;
      this.presentationInspectorOpen=true;
      this.refreshPresentationFocus();
      this.refreshFocusInspector();
      focusInspectorPanel.focus({preventScroll:true});
      requestAnimationFrame(()=>this.ensureFocusVisible());
    },
    movePresentationFocus(direction) {
      if(this.viewMode!=="view"||!this.presentationFocusId)return;
      const next=this.findDirectionalNeighbor(this.presentationFocusId,direction);
      if(!next)return;
      this.presentationFocusId=next.id;
      this.refreshPresentationFocus();
      if(this.presentationInspectorOpen)this.refreshFocusInspector();
      requestAnimationFrame(()=>this.ensureFocusVisible());
    },
    toggleFocusInspector() {
      if(this.viewMode!=="view"||!this.presentationFocusId)return;
      this.presentationInspectorOpen=!this.presentationInspectorOpen;
      if(this.presentationInspectorOpen){
        this.refreshFocusInspector();focusInspectorPanel.focus({preventScroll:true});
      } else {
        presentationInspector.classList.remove("open");
        presentationInspector.setAttribute("aria-hidden","true");
        root.focus({preventScroll:true});
      }
      requestAnimationFrame(()=>this.ensureFocusVisible());
    },
    closePresentationFocus() {
      this.presentationFocusId=null;
      this.presentationInspectorOpen=false;
      presentationInspector.classList.remove("open");
      presentationInspector.setAttribute("aria-hidden","true");
      this.refreshPresentationFocus();
      if(this.viewMode==="view")root.focus({preventScroll:true});
    },
    refreshFocusInspector() {
      const note=this.noteById(this.presentationFocusId);
      if(!note||!this.presentationInspectorOpen)return;
      const info=kindInfo(note.eventKind);
      focusInspectorPanel.dataset.kind=note.eventKind;
      focusInspectorIcon.textContent=info.icon||"◆";
      focusInspectorKind.textContent=info.label;
      focusInspectorTitle.textContent=note.title||info.label;
      const field=(label,value,isCode=false)=>{
        if(!value)return "";
        return `<section class="focus-inspector-field"><div class="focus-inspector-label">${escapeHtml(label)}</div>`+
          (isCode?`<pre class="focus-inspector-code">${escapeHtml(value)}</pre>`:`<div class="focus-inspector-value">${escapeHtml(value)}</div>`)+`</section>`;
      };
      const linkedNames=ids=>(ids||[]).map(id=>this.noteById(id)).filter(Boolean).map(n=>n.title||kindInfo(n.eventKind).label).join(" / ");
      const isRelation=["aggregate","policy","external_system"].includes(note.eventKind);
      const incoming=isRelation?linkedNames(note.inputIds):"";
      const outgoing=isRelation?linkedNames(note.outputIds):"";
      const incomingLabel=note.eventKind==="policy"?"入力 Event":"入力 Command";
      const outgoingLabel=note.eventKind==="policy"?"出力 Command":"出力 Event";
      const html=[
        field("内容 / メモ",note.text),
        field("ルール / 責務",note.ruleText),
        field(incomingLabel,incoming),
        field(outgoingLabel,outgoing),
        note.eventKind==="insight"?field("Insight / AI分析結果",note.resultMarkdown,true):"",
      ].filter(Boolean).join("");
      focusInspectorContent.innerHTML=html||'<div class="focus-inspector-muted">このオブジェクトには説明が登録されていません。</div>';
      presentationInspector.classList.add("open");
      presentationInspector.setAttribute("aria-hidden","false");
      for(const btn of presentationInspector.querySelectorAll("[data-focus-direction]")){
        btn.disabled=!this.findDirectionalNeighbor(note.id,btn.dataset.focusDirection);
      }
    },
    ensureFocusVisible() {
      const note=this.noteById(this.presentationFocusId);
      if(!note||this.viewMode!=="view")return;
      const logical=this.noteRect(note),z=this.boardZoom,margin=32;
      const vw=viewport.clientWidth,vh=viewport.clientHeight;
      // When the scaled board fits, a pan moves the board without scrollbars.
      // Correct any off-screen focus in that coordinate system before scrolling.
      let panX=this.panOffsetX,panY=this.panOffsetY;
      const focusWidth=logical.w*z,focusHeight=logical.h*z;
      if(canvas.offsetWidth*z<vw){
        if(logical.x*z+panX<margin)panX+=margin-(logical.x*z+panX);
        else if((logical.x+logical.w)*z+panX>vw-margin)panX-=((logical.x+logical.w)*z+panX)-(vw-margin);
      }
      if(canvas.offsetHeight*z<vh){
        if(logical.y*z+panY<margin)panY+=margin-(logical.y*z+panY);
        else if((logical.y+logical.h)*z+panY>vh-margin)panY-=((logical.y+logical.h)*z+panY)-(vh-margin);
      }
      this.setPanOffset(panX,panY);
      const r={x:logical.x*z+this.panOffsetX,y:logical.y*z+this.panOffsetY,w:focusWidth,h:focusHeight};
      let scrollX=viewport.scrollLeft,scrollY=viewport.scrollTop;
      if(r.x-margin<scrollX)scrollX=r.x-margin;
      else if(r.x+r.w+margin>scrollX+vw)scrollX=r.x+r.w+margin-vw;
      if(r.y-margin<scrollY)scrollY=r.y-margin;
      else if(r.y+r.h+margin>scrollY+vh)scrollY=r.y+r.h+margin-vh;
      scrollX=Math.max(0,Math.min(scrollX,viewport.scrollWidth-vw));
      scrollY=Math.max(0,Math.min(scrollY,viewport.scrollHeight-vh));
      // Keep the panel at full-size. During overview, place it opposite the
      // focused note so the red outline is less likely to be covered.
      focusInspectorPanel.classList.remove("placement-left","placement-right");
      if(this.presentationInspectorOpen && this.boardZoom<.85 && viewport.clientWidth>790){
        const screenCenter=r.x-scrollX+r.w/2;
        focusInspectorPanel.classList.add(screenCenter<viewport.clientWidth/2?"placement-right":"placement-left");
      }
      // Move an obscured focus note to a clear area beside the inspector.
      if(this.presentationInspectorOpen){
        const vr=viewport.getBoundingClientRect(),ir=focusInspectorPanel.getBoundingClientRect();
        const left=vr.left+r.x-scrollX, right=left+r.w;
        const top=vr.top+r.y-scrollY,bottom=top+r.h;
        const overlap=left<ir.right+16&&right>ir.left-16&&top<ir.bottom+16&&bottom>ir.top-16;
        if(overlap){
          const shiftLeft=right-(ir.left-18);
          const shiftedX=Math.min(viewport.scrollWidth-vw,scrollX+shiftLeft);
          if(ir.left-vr.left>=r.w+36 && shiftedX-scrollX>=shiftLeft-1){
            scrollX=shiftedX;
          } else {
            const shiftRight=(ir.right+18)-left;
            const shiftedRight=Math.max(0,scrollX-shiftRight);
            if(vr.right-ir.right>=r.w+36 && scrollX-shiftedRight>=shiftRight-1)scrollX=shiftedRight;
            else {
              // Narrow viewports: prefer keeping the focus above the card.
              const shiftUp=bottom-(ir.top-18);
              scrollY=Math.min(viewport.scrollHeight-vh,scrollY+Math.max(0,shiftUp));
            }
          }
        }
      }
      viewport.scrollTo({left:scrollX,top:scrollY,behavior:"smooth"});
    },

    snapshot() {
      this.history.push(clone(this.board));
      if (this.history.length > 80) this.history.shift();
      this.future = [];
    },
    sync() {
      const payload = clone(this.board);
      this.lastSyncedSerialized = JSON.stringify(payload);
      setStateValue("board", payload);
    },

    noteRect(note) {
      const info = kindInfo(note.eventKind);
      return {x: Number(note.x||0), y: Number(note.y||0), w: info.business ? Number(note.w||NOTE_W) : NODE_W, h: info.business ? Number(note.h||NOTE_H) : NODE_H};
    },
    center(rect) { return {x: rect.x + rect.w/2, y: rect.y + rect.h/2}; },
    boundaryPoint(rect, tx, ty) {
      const c = this.center(rect); const dx = tx-c.x; const dy = ty-c.y;
      if (Math.abs(dx)<.001 && Math.abs(dy)<.001) return c;
      const sx = Math.abs(dx)>.001 ? (rect.w/2)/Math.abs(dx) : Infinity;
      const sy = Math.abs(dy)>.001 ? (rect.h/2)/Math.abs(dy) : Infinity;
      const s = Math.min(sx, sy);
      return {x:c.x+dx*s, y:c.y+dy*s};
    },
    iconOutlineRect(note) {
      const item=[...noteLayer.querySelectorAll(".semantic-node")].find(el=>el.dataset.noteId===note.id);
      const icon=item?.querySelector(".node-icon");
      if (!icon) return this.noteRect(note);
      const iconBox=icon.getBoundingClientRect();
      const canvasBox=canvas.getBoundingClientRect();
      const style=getComputedStyle(icon);
      const outlineWidth=parseFloat(style.outlineWidth)||0;
      const outlineOffset=parseFloat(style.outlineOffset)||0;
      const pad=outlineWidth+outlineOffset;
      return {
        x: (iconBox.left-canvasBox.left)/this.boardZoom-pad,
        y: (iconBox.top-canvasBox.top)/this.boardZoom-pad,
        w: iconBox.width/this.boardZoom+pad*2,
        h: iconBox.height/this.boardZoom+pad*2,
      };
    },


    focusRelationNode() {
      if (this.showAllRelations) return null;
      const note = this.selectedNoteId ? this.noteById(this.selectedNoteId) : null;
      return note && ["aggregate","policy","external_system"].includes(note.eventKind) ? note : null;
    },
    focusIds() {
      if (this.showAllRelations) return null;
      const focus = this.focusRelationNode();
      if (!focus) return null;
      return new Set([focus.id, ...(focus.inputIds||[]), ...(focus.outputIds||[])]);
    },
    updateAllRelationsButton() {
      root.classList.toggle("all-relations-visible", this.showAllRelations);
      if (!allRelationsButton) return;
      allRelationsButton.classList.toggle("active", this.showAllRelations);
      allRelationsButton.setAttribute("aria-pressed", this.showAllRelations ? "true" : "false");
      allRelationsButton.textContent = this.showAllRelations ? "⇄ 全矢印 ON" : "⇄ 全矢印";
      allRelationsButton.title = this.showAllRelations
        ? "すべての関係矢印を非表示にする"
        : "Aggregate / Policy / External System の関係矢印をすべて表示";
    },
    toggleAllRelations() {
      this.showAllRelations = !this.showAllRelations;
      this.updateAllRelationsButton();
      this.refreshZControls();
      this.renderEdges();
    },

    refreshZControls() {
      const note=this.selectedNoteId ? this.noteById(this.selectedNoteId) : null;
      if (!note) {
        this.selectedNoteId=null;
        selectedSummary.textContent="未選択"; selectedSummary.title="要素を選択してください"; selectedSummary.classList.remove("has-selection");
        Object.values(zButtons).forEach(btn => btn.disabled=true);
      } else {
        const index=this.board.notes.findIndex(n=>n.id===note.id); const info=kindInfo(note.eventKind);
        const summary=`${info.icon||"■"} ${info.label}: ${note.title||note.text||"無題"}`; selectedSummary.textContent=summary; selectedSummary.title=summary; selectedSummary.classList.add("has-selection");
        zButtons.stepFront.disabled=index<0 || index>=this.board.notes.length-1;
        zButtons.front.disabled=zButtons.stepFront.disabled;
        zButtons.stepBack.disabled=index<=0;
        zButtons.back.disabled=zButtons.stepBack.disabled;
      }
      const focusIds=this.focusIds();
      noteLayer.querySelectorAll(".board-item").forEach(el => {
        const isSelected=!!this.selectedNoteId && el.dataset.noteId===this.selectedNoteId;
        el.classList.toggle("selected-note",isSelected);
        el.classList.toggle("presentation-focus",this.viewMode==="view" && el.dataset.noteId===this.presentationFocusId);
        el.classList.toggle("focus-dimmed",!!focusIds && !focusIds.has(el.dataset.noteId));
        el.classList.toggle("focus-related",!!focusIds && focusIds.has(el.dataset.noteId));
      });
    },
    selectNote(id) {
      const note=this.noteById(id);
      if (this.viewMode==="view") {
        if (!note || !["aggregate","policy","external_system"].includes(note.eventKind)) return;
        this.selectedNoteId=note.id;
        this.refreshZControls();
        this.renderEdges();
        return;
      }
      this.selectedNoteId=note ? note.id : null;
      this.refreshZControls();
      this.renderEdges();
    },
    moveZ(delta) {
      if (this.viewMode!=="edit" || !this.selectedNoteId) return;
      const i=this.board.notes.findIndex(n=>n.id===this.selectedNoteId); if (i<0) return;
      const j=Math.max(0,Math.min(this.board.notes.length-1,i+delta)); if (j===i) return;
      this.snapshot(); const [note]=this.board.notes.splice(i,1); this.board.notes.splice(j,0,note); this.render(); this.sync();
    },
    moveZExtreme(front) {
      if (this.viewMode!=="edit" || !this.selectedNoteId) return;
      const i=this.board.notes.findIndex(n=>n.id===this.selectedNoteId); if (i<0) return;
      const target=front ? this.board.notes.length-1 : 0; if (i===target) return;
      this.snapshot(); const [note]=this.board.notes.splice(i,1); front ? this.board.notes.push(note) : this.board.notes.unshift(note); this.render(); this.sync();
    },

    createNote(eventKind,x,y,title="",text="",showEditor=false) {
      if(this.viewMode!=="edit")return null;
      const info=kindInfo(eventKind);
      const w=info.business?NOTE_W:NODE_W,h=info.business?NOTE_H:NODE_H;
      const clampedX=Math.max(4,Math.min(canvas.offsetWidth-w-4,Math.round(x)));
      const clampedY=Math.max(110,Math.min(canvas.offsetHeight-h-4,Math.round(y)));
      const note={id:uid("note"),title:title||info.label,text,eventKind,
        color:info.business?info.color:"",x:clampedX,y:clampedY,w,h,
        inputIds:[],outputIds:[],ruleText:""};
      this.snapshot();
      this.board.notes.push(note);
      this.selectedNoteId=note.id;
      this.render();this.sync();
      if(showEditor)this.openNoteModal(note.id);
      return note;
    },
    addNote() {
      if(this.viewMode!=="edit")return;
      const eventKind=newKind.value,info=kindInfo(eventKind);
      const title=newTitle.value.trim(),text=newText.value.trim();
      if(!title&&!text){newTitle.focus();return;}
      const rect=viewport.getBoundingClientRect();
      const pos=this.clientToBoard(rect.left+Math.min(140,rect.width/2),rect.top+Math.min(200,rect.height/2));
      const note=this.createNote(eventKind,pos.x,pos.y,title,text,["aggregate","policy","external_system"].includes(eventKind));
      if(note){newTitle.value="";newText.value="";}
    },
    deleteNote(id) {
      if (this.viewMode!=="edit") return;
      this.snapshot(); this.board.notes=this.board.notes.filter(n=>n.id!==id);
      for (const note of this.board.notes) { note.inputIds=(note.inputIds||[]).filter(x=>x!==id); note.outputIds=(note.outputIds||[]).filter(x=>x!==id); }
      if (this.selectedNoteId===id) this.selectedNoteId=null; this.closeNoteModal(); this.render(); this.sync();
    },

    resizeCanvas() {
      let maxX=2850,maxY=1800;
      for (const note of this.board.notes) { const r=this.noteRect(note); maxX=Math.max(maxX,r.x+r.w+220); maxY=Math.max(maxY,r.y+r.h+220); }
      canvas.style.width=`${Math.ceil(maxX)}px`; canvas.style.height=`${Math.ceil(maxY)}px`;
      this.updateZoomSpace();
},

    drawLine(startRect,endRect,className,markerEnd=true) {
      const a=this.center(startRect), b=this.center(endRect); const start=this.boundaryPoint(startRect,b.x,b.y), end=this.boundaryPoint(endRect,a.x,a.y);
      const line=document.createElementNS("http://www.w3.org/2000/svg","line");
      line.setAttribute("x1",start.x); line.setAttribute("y1",start.y); line.setAttribute("x2",end.x); line.setAttribute("y2",end.y); line.setAttribute("class",className);
      if (markerEnd) line.setAttribute("marker-end","url(#semantic-arrow)");
      edgeLayer.appendChild(line); return {start,end};
    },
    renderEdges() {
      edgeLayer.innerHTML=`<defs>
        <marker id="semantic-arrow" markerWidth="20" markerHeight="16" refX="20" refY="8" orient="auto" markerUnits="userSpaceOnUse">
          <path class="semantic-arrow-head" d="M0,0 L20,8 L0,16 z"></path>
        </marker>
      </defs>`;

      const drawRelationsFor = (relationNode) => {
        const relationRect=this.iconOutlineRect(relationNode);
        for (const id of relationNode.inputIds||[]) {
          const note=this.noteById(id);
          if (note) this.drawLine(this.noteRect(note),relationRect,"semantic-edge input-edge");
        }
        for (const id of relationNode.outputIds||[]) {
          const note=this.noteById(id);
          if (note) this.drawLine(relationRect,this.noteRect(note),"semantic-edge output-edge");
        }
      };

      if (this.showAllRelations) {
        for (const note of this.board.notes) {
          if (["aggregate","policy","external_system"].includes(note.eventKind)) drawRelationsFor(note);
        }
        return;
      }

      const focus=this.focusRelationNode();
      if (focus) drawRelationsFor(focus);
    },

    attachDrag(note,element) {
      // Click still selects/edits. A 5px gesture moves from ANY non-control
      // surface, including the body; Alt+drag in the body selects text instead.
      element.addEventListener("pointerdown",evt=>{
        if(evt.button!==0||!evt.isPrimary||this.viewMode!=="edit"||this.mode!=="move")return;
        if(evt.target.closest('button,input,textarea,select,a'))return;
        if(evt.altKey && evt.target.closest('.note-body'))return;
        this.selectNote(note.id);
        const sx=evt.clientX,sy=evt.clientY,ox=note.x,oy=note.y;
        let moved=false;
        const pointerId=evt.pointerId;
        element.setPointerCapture(pointerId);
        const move=mv=>{
          if(mv.pointerId!==pointerId)return;
          const dx=mv.clientX-sx,dy=mv.clientY-sy;
          if(!moved && Math.hypot(dx,dy)<5)return;
          if(!moved){
            moved=true;
            this.snapshot();
            element.classList.add("is-note-dragging");
            // Avoid leaving an accidental text-selection highlight on a sticky note.
            window.getSelection()?.removeAllRanges();
          }
          mv.preventDefault();mv.stopPropagation();
          const r=this.noteRect(note),z=this.boardZoom;
          note.x=Math.max(4,Math.min(canvas.offsetWidth-r.w-4,ox+dx/z));
          note.y=Math.max(4,Math.min(canvas.offsetHeight-r.h-4,oy+dy/z));
          element.style.left=`${note.x}px`;element.style.top=`${note.y}px`;
          this.renderEdges();
        };
        const up=upEvt=>{
          if(upEvt.pointerId!==pointerId)return;
          try{element.releasePointerCapture(pointerId);}catch(_){}
          element.removeEventListener("pointermove",move);
          element.removeEventListener("pointerup",up);
          element.removeEventListener("pointercancel",up);
          element.classList.remove("is-note-dragging");
          if(moved){
            // Suppress the click synthesized after a drag, not a later click.
            element.dataset.ignoreDragClick="1";
            note.x=Math.round(note.x);note.y=Math.round(note.y);
            this.resizeCanvas();this.sync();
          }
        };
        element.addEventListener("pointermove",move);
        element.addEventListener("pointerup",up);
        element.addEventListener("pointercancel",up);
      });
    },
    renderNotes() {
      noteLayer.innerHTML=""; const focusIds=this.focusIds();
      this.board.notes.forEach((note,index)=>{
        const info=kindInfo(note.eventKind); const el=document.createElement("div");el.dataset.noteId=note.id;el.dataset.kind=note.eventKind;el.className=`board-item ${info.business?"business-note":"semantic-node"}`;
        el.style.left=`${note.x}px`;el.style.top=`${note.y}px`;el.style.zIndex=String(index+10);
        if(this.selectedNoteId===note.id)el.classList.add("selected-note");
        if(this.viewMode==="view"&&this.presentationFocusId===note.id)el.classList.add("presentation-focus");
        if(focusIds){if(focusIds.has(note.id))el.classList.add("focus-related");else el.classList.add("focus-dimmed");}
        el.addEventListener("click",evt=>{if(el.dataset.ignoreDragClick){delete el.dataset.ignoreDragClick;evt.preventDefault();evt.stopPropagation();return;}if(evt.target.closest("button"))return;evt.stopPropagation();this.selectNote(note.id);});
        el.addEventListener("dblclick",evt=>{if(evt.target.closest("button"))return;evt.preventDefault();evt.stopPropagation();if(this.viewMode==="view")this.openPresentationFocus(note.id);else this.openNoteModal(note.id);});

        let dragHandle;
        if(info.business){
          const handle=document.createElement("div");handle.className="note-handle";handle.innerHTML="<span>⠿</span>";dragHandle=handle;
          const del=document.createElement("button");del.className="note-delete";del.textContent="×";del.title="削除";del.addEventListener("click",evt=>{evt.stopPropagation();this.deleteNote(note.id);});handle.appendChild(del);el.appendChild(handle);
          const title=document.createElement("div");title.className="note-title";title.innerHTML=`<span class="note-title-text">${escapeHtml(note.title||info.label)}</span><span class="note-type-badge">${escapeHtml(info.label)}</span>`;el.appendChild(title);
          const body=document.createElement("div");body.className="note-body";body.textContent=note.text;body.spellcheck=false;body.contentEditable=this.viewMode==="edit"?"true":"false";
          if(this.viewMode==="edit"){
            body.addEventListener("click",e=>{if(el.dataset.ignoreDragClick){delete el.dataset.ignoreDragClick;e.preventDefault();}e.stopPropagation();});
            body.addEventListener("blur",()=>{const next=body.textContent??"";if(next!==note.text){this.snapshot();note.text=next;this.sync();}});
            body.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter")body.blur();});
          }
          el.appendChild(body);
        } else {
          const del=document.createElement("button");del.className="node-delete";del.textContent="×";del.title="削除";del.addEventListener("click",evt=>{evt.stopPropagation();this.deleteNote(note.id);});el.appendChild(del);
          const icon=document.createElement("div");icon.className="node-icon";icon.textContent=info.icon||"●";dragHandle=icon;el.appendChild(icon);
          const title=document.createElement("div");title.className="node-title";title.textContent=note.title||info.label;title.title=note.title||info.label;el.appendChild(title);
        }
        this.attachDrag(note,el);noteLayer.appendChild(el);
      });
      this.refreshZControls();
    },

    relationCandidates(kind,direction) {
      const commandToEvent = ["aggregate","external_system"].includes(kind);
      const wanted = commandToEvent ? (direction==="input"?"command":"domain_event") : (direction==="input"?"domain_event":"command");
      return this.board.notes.filter(n=>n.eventKind===wanted).sort((a,b)=>(a.x-b.x)||(a.y-b.y));
    },
    relationOptionsHtml(candidates,selectedIds) {
      if(!candidates.length)return `<div class="relation-empty">候補となる付箋がありません。</div>`;
      const selected=new Set(selectedIds||[]);
      return candidates.map(n=>`<label class="relation-option"><input type="checkbox" value="${escapeHtml(n.id)}" ${selected.has(n.id)?"checked":""}/><span><strong>${escapeHtml(n.title||kindInfo(n.eventKind).label)}</strong><br>${escapeHtml((n.text||"").slice(0,110))}</span></label>`).join("");
    },
    openRelationEditor(note) {
      const info=kindInfo(note.eventKind);noteModalTitle.textContent=`${info.icon} ${note.title||info.label}`;
      const commandToEvent=["aggregate","external_system"].includes(note.eventKind);
      const inputLabel=commandToEvent?"入力 Command":"入力 Event";const outputLabel=commandToEvent?"出力 Event":"出力 Command";
      noteModalContent.innerHTML=`<div class="editor-grid"><label class="editor-field full"><span>タイトル</span><input class="edit-title" value="${escapeHtml(note.title||info.label)}"/></label></div>
        <div class="relation-grid"><section class="relation-column"><h3>${inputLabel}（複数選択可）</h3><div class="relation-options input-options">${this.relationOptionsHtml(this.relationCandidates(note.eventKind,"input"),note.inputIds)}</div></section>
        <section class="relation-column"><h3>${outputLabel}（複数選択可）</h3><div class="relation-options output-options">${this.relationOptionsHtml(this.relationCandidates(note.eventKind,"output"),note.outputIds)}</div></section></div>
        <label class="editor-field full" style="margin-top:.8rem"><span>${note.eventKind==="aggregate"?"Aggregate のルール / Invariant":note.eventKind==="external_system"?"External System の責務 / Interface メモ":"Policy / Rule の内容"}</span><textarea class="edit-rule tall">${escapeHtml(note.ruleText||"")}</textarea></label>`;
      noteModalFooter.innerHTML="";
      const cancel=document.createElement("button");cancel.textContent="キャンセル";cancel.onclick=()=>this.closeNoteModal();
      const save=document.createElement("button");save.className="primary-btn";save.textContent="保存";save.onclick=()=>{
        this.snapshot();note.title=noteModalContent.querySelector(".edit-title").value.trim()||info.label;
        note.inputIds=[...noteModalContent.querySelectorAll(".input-options input:checked")].map(x=>x.value);note.outputIds=[...noteModalContent.querySelectorAll(".output-options input:checked")].map(x=>x.value);note.ruleText=noteModalContent.querySelector(".edit-rule").value;this.closeNoteModal();this.selectedNoteId=note.id;this.render();this.sync();
      };noteModalFooter.append(cancel,save);
    },
    relationMermaidSource(note) {
      const info=kindInfo(note.eventKind);
      const inputs=(note.inputIds||[]).map(id=>this.noteById(id)).filter(Boolean);
      const outputs=(note.outputIds||[]).map(id=>this.noteById(id)).filter(Boolean);
      const lines=[
        "flowchart LR",
        "  classDef command fill:#9fd4ff,stroke:#334155,color:#111827,stroke-width:1px;",
        "  classDef event fill:#ffb35c,stroke:#334155,color:#111827,stroke-width:1px;",
        "  classDef semantic fill:#ffffff,stroke:#e53935,color:#111827,stroke-width:3px;",
        `  N["${mermaidLabel((info.icon||"")+" "+(note.title||info.label))}"]:::semantic`,
      ];
      inputs.forEach((item,index)=>{
        const cls=item.eventKind==="domain_event"?"event":"command";
        lines.push(`  I${index}["${mermaidLabel(item.title||kindInfo(item.eventKind).label)}"]:::${cls}`);
        lines.push(`  I${index} --> N`);
      });
      outputs.forEach((item,index)=>{
        const cls=item.eventKind==="domain_event"?"event":"command";
        lines.push(`  O${index}["${mermaidLabel(item.title||kindInfo(item.eventKind).label)}"]:::${cls}`);
        lines.push(`  N --> O${index}`);
      });
      if (!inputs.length && !outputs.length) lines.push('  EMPTY["入出力付箋が設定されていません"] -.-> N');
      return lines.join("\n");
    },
    async openRelationViewer(note) {
      const info=kindInfo(note.eventKind);
      noteModalTitle.textContent=`${info.icon} ${note.title||info.label}`;
      const ruleLabel=note.eventKind==="aggregate"?"Aggregate のルール / Invariant":note.eventKind==="external_system"?"External System の責務 / Interface メモ":"Policy / Rule の内容";
      noteModalContent.innerHTML=`<div class="relation-viewer"><div class="mermaid-preview"></div>${note.ruleText?`<div class="relation-rule-view"><strong>${escapeHtml(ruleLabel)}</strong>${escapeHtml(note.ruleText)}</div>`:""}</div>`;
      await renderMermaidFlow(this.relationMermaidSource(note),noteModalContent.querySelector(".mermaid-preview"));
      noteModalFooter.innerHTML="";
      const close=document.createElement("button");close.className="primary-btn";close.textContent="閉じる";close.onclick=()=>this.closeNoteModal();noteModalFooter.append(close);
    },

    openGenericEditor(note) {
      const info=kindInfo(note.eventKind);noteModalTitle.textContent=`${info.icon||"■"} ${note.title||info.label}`;
      const allowedKinds=["domain_event","command","read_model","aggregate","policy","actor","hotspot","external_system"];
      const options=allowedKinds.map(k=>`<option value="${k}" ${k===note.eventKind?"selected":""}>${escapeHtml((kindInfo(k).icon||"")+" "+kindInfo(k).label)}</option>`).join("");
      noteModalContent.innerHTML=`<div class="editor-grid"><label class="editor-field"><span>種類</span><select class="edit-kind">${options}</select></label><label class="editor-field"><span>タイトル</span><input class="edit-title" value="${escapeHtml(note.title)}"/></label><label class="editor-field full"><span>内容 / メモ</span><textarea class="edit-text tall">${escapeHtml(note.text)}</textarea></label></div>`;
      noteModalFooter.innerHTML="";const cancel=document.createElement("button");cancel.textContent="キャンセル";cancel.onclick=()=>this.closeNoteModal();const save=document.createElement("button");save.className="primary-btn";save.textContent="保存";save.onclick=()=>{this.snapshot();const nextKind=noteModalContent.querySelector(".edit-kind").value;note.eventKind=nextKind;note.title=noteModalContent.querySelector(".edit-title").value.trim()||kindInfo(nextKind).label;note.text=noteModalContent.querySelector(".edit-text").value;const nextInfo=kindInfo(nextKind);note.color=nextInfo.business?nextInfo.color:"";note.w=nextInfo.business?NOTE_W:NODE_W;note.h=nextInfo.business?NOTE_H:NODE_H;this.closeNoteModal();this.render();this.sync();};noteModalFooter.append(cancel,save);
    },
    openHotspotViewer(note) {
      const info=kindInfo(note.eventKind);
      noteModalTitle.textContent=`${info.icon||"🔥"} ${note.title||info.label}`;
      const memo=(note.text||"").trim();
      noteModalContent.innerHTML=`<div class="relation-viewer"><div class="relation-rule-view"><strong>内容・メモ</strong><div class="hotspot-memo-view">${escapeHtml(memo||"（内容・メモはありません）")}</div></div></div>`;
      noteModalFooter.innerHTML="";
      const close=document.createElement("button");close.className="primary-btn";close.textContent="閉じる";close.onclick=()=>this.closeNoteModal();noteModalFooter.append(close);
    },
    openNoteModal(id) {
      const note=this.noteById(id);if(!note)return;
      const isRelation=["aggregate","policy","external_system"].includes(note.eventKind);
      const isHotspot=note.eventKind==="hotspot";
      if(this.viewMode==="view" && !isRelation && !isHotspot)return;
      this.activeNoteId=id;noteModal.classList.add("open");noteModal.setAttribute("aria-hidden","false");
      if(this.viewMode==="view" && isRelation)this.openRelationViewer(note);
      else if(this.viewMode==="view" && isHotspot)this.openHotspotViewer(note);
      else if(isRelation)this.openRelationEditor(note);
      else this.openGenericEditor(note);
    },
    closeNoteModal() { this.activeNoteId=null;noteModal.classList.remove("open");noteModal.setAttribute("aria-hidden","true");noteModalContent.innerHTML="";noteModalFooter.innerHTML=""; },

    setViewMode(mode) {
      this.closePresentationFocus();
      this.viewMode=mode==="view"?"view":"edit";
      root.classList.toggle("view-mode",this.viewMode==="view");
      root.classList.toggle("edit-mode",this.viewMode==="edit");
      root.querySelectorAll(".view-btn").forEach(btn=>btn.classList.toggle("active",btn.dataset.view===this.viewMode));
      if(this.viewMode==="view")this.selectedNoteId=null;
      this.closeNoteModal();
      this.render();
    },

    renderTitle() { const title=this.board.title||"";if(document.activeElement!==titleInput)titleInput.value=title;titleDisplay.textContent=title||"Event Storming Session"; },
    renderStats() { const counts={};for(const note of this.board.notes)counts[note.eventKind]=(counts[note.eventKind]||0)+1;const full=`Event ${counts.domain_event||0} / Command ${counts.command||0} / Aggregate ${counts.aggregate||0} / Policy ${counts.policy||0} / External ${counts.external_system||0}`;stats.textContent=`E${counts.domain_event||0} C${counts.command||0} A${counts.aggregate||0} P${counts.policy||0} X${counts.external_system||0}`;stats.title=full; },
    render() { this.resizeCanvas();this.renderTitle();this.updateAllRelationsButton();this.renderNotes();this.renderEdges();this.renderStats();requestAnimationFrame(updateHorizontalScrollSlider); },
    undo() { if(this.viewMode!=="edit"||!this.history.length)return;this.future.push(clone(this.board));this.board=this.history.pop();if(this.selectedNoteId&&!this.noteById(this.selectedNoteId))this.selectedNoteId=null;this.render();this.sync(); },
    redo() { if(this.viewMode!=="edit"||!this.future.length)return;this.history.push(clone(this.board));this.board=this.future.pop();if(this.selectedNoteId&&!this.noteById(this.selectedNoteId))this.selectedNoteId=null;this.render();this.sync(); },
    reset() { if(this.viewMode!=="edit"||!window.confirm("ボードを全消去しますか？"))return;this.snapshot();this.board={title:this.board.title||"",notes:[]};this.selectedNoteId=null;this.render();this.sync(); },

    async downloadPng() {
      const button=root.querySelector('[data-action="export-png"]');
      const originalLabel=button?.textContent||"PNG";
      if(button){button.disabled=true;button.textContent="…";}
      const oldBackground=canvas.style.background;
      const oldBackgroundSize=canvas.style.backgroundSize;
      const oldBackgroundPosition=canvas.style.backgroundPosition;
      try{
        const viewportStyle=getComputedStyle(viewport);
        canvas.style.background=viewportStyle.background;
        canvas.style.backgroundSize=viewportStyle.backgroundSize;
        canvas.style.backgroundPosition=viewportStyle.backgroundPosition;

        await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
        const htmlToImage=await getHtmlToImage();
        const dataUrl=await htmlToImage.toPng(canvas,{
          cacheBust:true,
          pixelRatio:1,
          width:canvas.scrollWidth,
          height:canvas.scrollHeight,
          canvasWidth:canvas.scrollWidth,
          canvasHeight:canvas.scrollHeight,
          // Export the original full-size board, not the on-screen overview.
          style:{transform:"none",transformOrigin:"top left","--focus-ring-offset":"4px","--focus-ring-outer":"8px","--relation-stroke-width":"3px"},
        });

        const a=document.createElement("a");
        const d=new Date(),pad=n=>String(n).padStart(2,"0");
        a.href=dataUrl;
        a.download=`event-storming-board-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.png`;
        document.body.appendChild(a);a.click();a.remove();
      }catch(err){
        window.alert(`PNG保存エラー\n${err?.message||err}`);
      }finally{
        canvas.style.background=oldBackground;
        canvas.style.backgroundSize=oldBackgroundSize;
        canvas.style.backgroundPosition=oldBackgroundPosition;
        if(button){button.disabled=false;button.textContent=originalLabel;}
      }
    },

    downloadJson() { const blob=new Blob([JSON.stringify(this.board,null,2)],{type:"application/json;charset=utf-8"});const url=URL.createObjectURL(blob),a=document.createElement("a");const d=new Date(),pad=n=>String(n).padStart(2,"0");a.href=url;a.download=`event-storming-board-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200); },
    async importJson(file) { if(!file)return;try{const parsed=JSON.parse(await file.text());if(!parsed||!Array.isArray(parsed.notes))throw new Error("notes 配列がありません");if(!window.confirm("現在のボードを読み込んだ内容で置き換えますか？"))return;this.snapshot();this.board=normalizeBoard(parsed);this.selectedNoteId=null;this.closeNoteModal();this.render();this.sync();}catch(err){window.alert(`JSON読込エラー\n${err?.message||err}`);}finally{fileInput.value="";} },
  };

  parentElement.__esApp=app;

  // Drag source is in the fixed (unscaled) toolbar; drop uses canvas coordinates.
  const paletteButtons=root.querySelectorAll("[data-create-kind]");
  let paletteGhost=null;
  const pointerInViewport=(x,y)=>{
    const r=viewport.getBoundingClientRect();
    return x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom;
  };
  const hidePaletteGhost=()=>{
    if(paletteGhost){paletteGhost.remove();paletteGhost=null;}
    viewport.classList.remove("palette-drop-target");
  };
  for(const button of paletteButtons){
    let suppressClick=false;
    button.addEventListener("pointerdown",e=>{
      if(e.button!==0||!e.isPrimary||app.viewMode!=="edit")return;
      const kind=button.dataset.createKind;
      const sx=e.clientX,sy=e.clientY,pointerId=e.pointerId;
      let dragging=false;
      button.setPointerCapture(pointerId);
      const move=ev=>{
        if(ev.pointerId!==pointerId)return;
        if(!dragging&&Math.hypot(ev.clientX-sx,ev.clientY-sy)<5)return;
        if(!dragging){
          dragging=true;
          paletteGhost=document.createElement("div");
          paletteGhost.className=`palette-drag-ghost ${kindInfo(kind).business?"palette-drag-sticky":"palette-drag-node"}`;
          paletteGhost.textContent=kindInfo(kind).business?kindInfo(kind).label:(kindInfo(kind).icon+" "+kindInfo(kind).label);
          paletteGhost.style.setProperty("--ghost-color",kindInfo(kind).color||"#e5edf6");
          root.appendChild(paletteGhost);
        }
        paletteGhost.style.left=`${ev.clientX}px`;
        paletteGhost.style.top=`${ev.clientY}px`;
        viewport.classList.toggle("palette-drop-target",pointerInViewport(ev.clientX,ev.clientY));
        ev.preventDefault();
      };
      const up=ev=>{
        if(ev.pointerId!==pointerId)return;
        try{button.releasePointerCapture(pointerId);}catch(_){}
        button.removeEventListener("pointermove",move);
        button.removeEventListener("pointerup",up);
        button.removeEventListener("pointercancel",up);
        hidePaletteGhost();
        if(dragging){
          suppressClick=ev.type==="pointerup";
          if(ev.type==="pointerup"&&pointerInViewport(ev.clientX,ev.clientY)){
            const kindDef=kindInfo(kind);
            const pos=app.clientToBoard(ev.clientX,ev.clientY);
            app.createNote(kind,pos.x-(kindDef.business?NOTE_W:NODE_W)/2,pos.y-(kindDef.business?NOTE_H:NODE_H)/2);
          }
        }
      };
      button.addEventListener("pointermove",move);
      button.addEventListener("pointerup",up);
      button.addEventListener("pointercancel",up);
    });
    button.addEventListener("click",e=>{
      if(suppressClick){suppressClick=false;e.preventDefault();return;}
      if(app.viewMode!=="edit")return;
      const rect=viewport.getBoundingClientRect();
      const pos=app.clientToBoard(rect.left+rect.width/2,rect.top+rect.height/2);
      const info=kindInfo(button.dataset.createKind);
      app.createNote(button.dataset.createKind,pos.x-(info.business?NOTE_W:NODE_W)/2,pos.y-(info.business?NOTE_H:NODE_H)/2);
    });
  }

  root.querySelector('[data-action="add-note"]').onclick=()=>app.addNote();
  newText.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter"){e.preventDefault();app.addNote();}});
  titleInput.addEventListener("blur",()=>{const next=titleInput.value.trim();if(next===(app.board.title||""))return;app.snapshot();app.board.title=next;app.renderTitle();app.sync();});
  titleInput.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();titleInput.blur();}});
  root.querySelectorAll(".view-btn").forEach(btn=>btn.onclick=()=>app.setViewMode(btn.dataset.view));
  if (allRelationsButton) allRelationsButton.onclick=()=>app.toggleAllRelations();
  zButtons.stepFront.onclick=()=>app.moveZ(1);zButtons.stepBack.onclick=()=>app.moveZ(-1);zButtons.front.onclick=()=>app.moveZExtreme(true);zButtons.back.onclick=()=>app.moveZExtreme(false);
  root.querySelector('[data-action="undo"]').onclick=()=>app.undo();root.querySelector('[data-action="redo"]').onclick=()=>app.redo();root.querySelector('[data-action="reset"]').onclick=()=>app.reset();
  root.querySelector('[data-action="export-json"]').onclick=()=>app.downloadJson();root.querySelector('[data-action="import-json"]').onclick=()=>{fileInput.value="";fileInput.click();};fileInput.onchange=()=>app.importJson(fileInput.files?.[0]);
  root.querySelector('[data-action="fullscreen"]').onclick=async()=>{try{if(!document.fullscreenElement)await root.requestFullscreen();else await document.exitFullscreen();}catch(err){window.alert(`全画面表示エラー\n${err?.message||err}`);}};
  root.querySelector('[data-action="export-png"]').onclick=()=>app.downloadPng();
  zoomSlider.oninput=()=>app.setBoardZoom(Number(zoomSlider.value)/100);
  root.querySelector('[data-action="zoom-out"]').onclick=()=>app.setBoardZoom(app.boardZoom-.10);
  root.querySelector('[data-action="zoom-in"]').onclick=()=>app.setBoardZoom(app.boardZoom+.10);
  root.querySelector('[data-action="zoom-fit"]').onclick=()=>app.fitBoardToView();
  horizontalScrollSlider?.addEventListener("input",()=>{ viewport.scrollLeft=Number(horizontalScrollSlider.value)||0; });
  viewport.addEventListener("wheel",e=>{
    if(e.ctrlKey||e.metaKey)return;  // Respect explicit browser/page zoom shortcuts.
    e.preventDefault();
    if(e.shiftKey){
      viewport.scrollLeft+=e.deltaY||e.deltaX;
      updateHorizontalScrollSlider();
      return;
    }
    // Trackpads have smaller deltaY values; exponential steps stay smooth.
    const delta=e.deltaMode===1?e.deltaY*16:e.deltaMode===2?e.deltaY*viewport.clientHeight:e.deltaY;
    const next=app.boardZoomTarget*Math.exp(-delta*0.0012);
    app.setBoardZoom(next,{clientX:e.clientX,clientY:e.clientY});
  },{passive:false});
  viewport.addEventListener("scroll",updateHorizontalScrollSlider,{passive:true});
  // Grab-to-pan: do not intercept notes, edit fields, or the presentation toolbar.
  // Pointer capture retains drag when leaving the viewport during a gesture.
  let boardPanGesture=null;
  viewport.addEventListener("pointerdown",e=>{
    if(e.button!==0||!e.isPrimary||e.target.closest('.board-item,.session-title-panel,button,input,textarea,select,a,[contenteditable="true"]'))return;
    if(boardPanGesture)return;
    boardPanGesture={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,
      scrollX:viewport.scrollLeft,scrollY:viewport.scrollTop,
      offsetX:app.panOffsetX,offsetY:app.panOffsetY,moved:false};
    viewport.setPointerCapture(e.pointerId);
  });
  viewport.addEventListener("pointermove",e=>{
    const g=boardPanGesture;
    if(!g||e.pointerId!==g.pointerId)return;
    const dx=e.clientX-g.startX,dy=e.clientY-g.startY;
    if(!g.moved&&Math.hypot(dx,dy)<4)return;
    g.moved=true;
    viewport.classList.add("is-panning");
    const extentX=canvas.offsetWidth*app.boardZoom,extentY=canvas.offsetHeight*app.boardZoom;
    if(extentX>viewport.clientWidth)viewport.scrollLeft=g.scrollX-dx;
    if(extentY>viewport.clientHeight)viewport.scrollTop=g.scrollY-dy;
    app.setPanOffset(g.offsetX+(extentX<=viewport.clientWidth?dx:0),
                     g.offsetY+(extentY<=viewport.clientHeight?dy:0));
    e.preventDefault();
  });
  const endBoardPan=e=>{
    if(!boardPanGesture||e.pointerId!==boardPanGesture.pointerId)return;
    try{viewport.releasePointerCapture(e.pointerId);}catch(_){}
    boardPanGesture=null;
    viewport.classList.remove("is-panning");
    updateHorizontalScrollSlider();
  };
  viewport.addEventListener("pointerup",endBoardPan);
  viewport.addEventListener("pointercancel",endBoardPan);
  document.addEventListener("fullscreenchange",()=>requestAnimationFrame(()=>{updateHorizontalScrollSlider();if(app.presentationFocusId)app.ensureFocusVisible();}));
  const horizontalScrollResizeObserver = new ResizeObserver(()=>{updateHorizontalScrollSlider();if(app.viewMode==="view"&&app.presentationFocusId)app.ensureFocusVisible();});
  horizontalScrollResizeObserver.observe(viewport);
  root.querySelectorAll('[data-action="close-note-modal"]').forEach(el=>el.onclick=()=>app.closeNoteModal());
  root.querySelector('[data-action="hide-focus-inspector"]').onclick=()=>app.toggleFocusInspector();
  root.querySelector('[data-action="exit-presentation-focus"]').onclick=()=>app.closePresentationFocus();
  root.querySelectorAll('[data-focus-direction]').forEach(btn=>btn.onclick=()=>{
    app.movePresentationFocus(btn.dataset.focusDirection);
    focusInspectorPanel.focus({preventScroll:true});
  });
  root.addEventListener("keydown",e=>{
    if(e.key==="Escape"){
      if(app.presentationFocusId){e.preventDefault();app.closePresentationFocus();}
      else app.closeNoteModal();
      return;
    }
    if(app.viewMode!=="view"||!app.presentationFocusId||e.altKey||e.ctrlKey||e.metaKey)return;
    if(e.target.closest('input,textarea,select,[contenteditable="true"]'))return;
    if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key)){
      e.preventDefault();app.movePresentationFocus(e.key);
    }else if((e.key===" "||e.key==="Spacebar")&&!e.target.closest('button,a')){
      e.preventDefault();app.toggleFocusInspector();
    }
  });

  canvas.addEventListener("click",e=>{if(e.target===canvas||e.target===noteLayer||e.target===edgeLayer){app.selectedNoteId=null;app.refreshZControls();app.renderEdges();}});

  app.setViewMode("edit");if(!data?.board||!Array.isArray(data.board.notes))app.sync();
  return()=>{horizontalScrollResizeObserver.disconnect();delete parentElement.__esApp;};
}
"""

EVENT_STORMING_BOARD_COMPONENT = st.components.v2.component(
    "event_storming_board",
    html=HTML,
    css=CSS,
    js=JS,
)


def get_component_board(key: str) -> dict[str, Any]:
    component_state = st.session_state.get(key, {})
    if isinstance(component_state, dict) and isinstance(component_state.get("board"), dict):
        return copy.deepcopy(component_state["board"])
    return copy.deepcopy(st.session_state.get("board_seed", EMPTY_BOARD))


if "board_seed" not in st.session_state:
    st.session_state.board_seed = copy.deepcopy(EMPTY_BOARD)

st.title("Event Storming Board")
st.caption(
    "Event / Command / Read Model は付箋、Aggregate / Policy / Actor / Hot Spot / External System は意味を持つノードとして表示します。"
)

with st.expander("操作ガイド", expanded=False):
    st.markdown(
        """
- **業務要素**: Domain Event / Command / Read Model は、黒文字で読める一般的なポストイット調の淡色付箋です。
- **意味を持つノード**: 🏛️ Aggregate / ⚙️ Policy / 👤 Actor / 🔥 Hot Spot / 📡 External System は、アイコン＋タイトルで表示します。
- **Aggregate**: ダブルクリックで複数の **入力 Command** と **出力 Event** を関連付け、ルール / Invariant を記述します。
- **Policy**: ダブルクリックで複数の **入力 Event** と **出力 Command** を関連付け、Policy / Rule を記述します。
- **External System**: 📡 をダブルクリックして複数の **入力 Command** と **出力 Event** を関連付けます。Aggregate と同様、選択時のみ関係矢印を表示します。
- **拡大・縮小**: ボード上でマウスホイールを回すと、ポインター位置を中心に5%〜250%の範囲でズームできます。Shift＋ホイールで横スクロールします。
- **要素の作成**: 上部の種類別アイコンをボードへドラッグ＆ドロップすると、その位置に付箋・ノードを生成します。アイコンをクリックした場合は画面中央付近へ配置します。
- **付箋の移動**: 付箋のどの位置からでもドラッグ可能です。本文のテキスト範囲をマウス選択する場合は Alt＋ドラッグを使用してください（クリックによる直接編集は従来どおり可能）。
- **ボード移動**: 空白部分をマウス左ボタンでドラッグすると、縮小表示で全体が収まっている状態を含め、ボードの表示位置を移動できます。付箋のドラッグ操作とは独立しています。
- **関係フォーカス**: Aggregate / Policy / External System をクリックすると、選択ノードと入出力付箋だけを強調し、その他の要素をブラー表示します。入出力の矢印もこのときだけ表示します。
- **表示モード / Focus Walkthrough**: オブジェクトをダブルクリックして赤枠と読み取り専用の説明カードを表示します。方向キー（← ↑ ↓ →）で空間上の隣接オブジェクトに移動し、画面外なら自動スクロールします。Space で説明カードの開閉、Esc でフォーカス終了です。
- **Z順**: 選択した要素を **前面へ / 背面へ / 最前面へ / 最背面へ** 移動できます。JSON保存と Undo / Redo の対象です。
        """
    )

component_key = "event_storming_board_component"
current_board = get_component_board(component_key)
result = EVENT_STORMING_BOARD_COMPONENT(
    data={"board": current_board},
    default={"board": current_board},
    key=component_key,
    on_board_change=lambda: None,
)

board = getattr(result, "board", current_board) or current_board
st.session_state.board_seed = copy.deepcopy(board)


counts: dict[str, int] = {}
for item in board.get("notes", []):
    kind = str(item.get("eventKind", "domain_event"))
    counts[kind] = counts.get(kind, 0) + 1

c1, c2, c3, c4 = st.columns(4)
c1.metric("Domain Event", counts.get("domain_event", 0))
c2.metric("Command", counts.get("command", 0))
c3.metric("Aggregate / Policy", counts.get("aggregate", 0) + counts.get("policy", 0))
c4.metric("External System", counts.get("external_system", 0))