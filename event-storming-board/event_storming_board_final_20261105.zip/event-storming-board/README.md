# Event Storming Board — Streamlit アプリケーション

## 同梱したバージョン

- `event_storming_app.py`: 2026年10月10日（日本時間）時点の `event_storming_app_miro.py` を採用した Miro 型インターフェース版。
- 外部システムのアイコンは **📡** に変更済み。
- 元の Python ファイルに埋め込まれている HTML / CSS / JavaScript をそのまま利用する構成のため、Node.js のビルドや別途フロントエンド資材は不要です。

## 動作環境

- Python 3.10 以降を推奨
- Streamlit 1.51 以上（Custom Components v2 API が必要）
- ブラウザー: Chrome / Edge などのモダンブラウザー

## 起動手順

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run event_storming_app.py
```

PowerShell の実行ポリシーにより有効化できない場合は、`.venv\Scripts\python.exe -m pip ...` のように直接実行できます。

### Linux / WSL / Ubuntu / RHEL

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run event_storming_app.py
```

起動後は、Streamlit が表示したローカル URL（通常 `http://localhost:8501`）を開きます。

## 主な操作

- 上部の要素パレットからボードへドラッグ＆ドロップしてノードを作成
- Event / Command / Read Model の付箋は正方形で、付箋上の任意の操作可能領域をドラッグして移動
- マウスホイールで拡大・縮小（ポインター位置を中心に操作）
- 空白領域のドラッグでボードをパン
- Aggregate / Policy / External System の関連づけ・選択時の関係矢印表示
- 編集 / 表示モード、ポップアップ、JSON のインポート・エクスポート、PNG 保存

## サンプルデータ

`samples/` 配下に次の JSON を同梱しています。

- `ec_shop_order_shipping_sample.json`: EC サイト注文から発送まで
- `event_storming_ride_booking_sample.json`: 配車業務

アプリの JSON 読み込み機能から取り込めます。

## 検証状況

Python の構文検査、埋め込み JavaScript の構文検査（Node.js が使用できる場合）、サンプル JSON の妥当性検査、および ZIP の整合性検査を実施しています。ブラウザー上での実際のドラッグ・ドロップ操作等については、この環境で統合テストを実施していません。

## 出典・復元について

本アーカイブのアプリ本体は、ユーザーのライブラリにある最新の `event_storming_app_miro.py` のテキストを復元して再構成したものです。取得経路の都合で元ファイルとのバイナリ同一性は未確認です（テキスト化されたファイルを用いています）。
